Framework.Notify = (function() {
	/**
	 * Notification object
	 *
	 * @class Notify
	 * @param {NodeElement} el
	 */
	var Notify = function(el) {
		this._el = el;

		this._HIDE_TIMEOUT = 1500; // [ms]

		this._options = {
			"ok": "alert-success",
			"error": "alert-danger",
			"info": "alert-info"
		};

		return this;
	};

	/**
	 * Set value to the notify element
	 *
	 * @private
	 * @param  {String|NodeElement} txt
	 * @memberof Notify
	 */
	Notify.prototype._setValue = function(txt) {
		if (Framework.Common.isElement(txt)) {
			Framework.MyQuery.get(this._el).empty().append(txt);
		}
		else if (typeof txt === "string") {
			this._el.innerHTML = txt;
		}
	};

	/**
	 * Reset classess
	 *
	 * @public
	 * @memberof Notify
	 */
	Notify.prototype.reset = function() {
		Object.keys(this._options).forEach(function(key) {
			this._el.classList.remove(this._options[key]);
		}.bind(this));

		return this;
	};

	/**
	 * Show OK state
	 * 
	 * @public
	 * @param  {String|NodeElement} txt
	 * @memberof Notify
	 */
	Notify.prototype.ok = function(txt) {
		this._el.classList.add(this._options["ok"]);
		
		this._setValue(txt);

		return this;
	};

	/**
	 * Show ERROR state
	 * 
	 * @public
	 * @param  {String|NodeElement} txt
	 * @memberof Notify
	 */
	Notify.prototype.error = function(txt) {
		this._el.classList.add(this._options["error"]);
		
		this._setValue(txt);

		return this;
	};

	/**
	 * Show INFO state
	 *
	 * @public
	 * @param  {String|NodeElement} txt
	 * @memberof Notify
	 */
	Notify.prototype.info = function(txt) {
		this._el.classList.add(this._options["info"]);
		
		this._setValue(txt);

		return this;
	};

	/**
	 * Timeout hide.
	 *
	 * @public
	 * @return {Framework.Promise}
	 * @memberof Notify
	 */
	Notify.prototype.hide = function() {
		var promise = Framework.Promise.defer();

		setTimeout(function() {
			this.reset();
			
			promise.resolve();
		}.bind(this), this._HIDE_TIMEOUT);

		return promise;
	};

	return {
		/**
		 * Main public access to the notify obj.
		 *
		 * @public
		 * @param  {NodeElement} el
		 * @return {Notify}
		 */
		get: function(el) {
			return new Notify(el);
		}
	};
})();
