// main framework object
Framework = (function() {
	var Framework = {
		// delimeter for Framework.Template
		TMPL_DELIMITER: {
			LEFT: "{",
			RIGHT: "}"
		}
	};
	
	// dom ready
	document.addEventListener("DOMContentLoaded", function() {
		// event - dom ready
		Framework.trigger("dom-ready");
	});

	return Framework;
})();
