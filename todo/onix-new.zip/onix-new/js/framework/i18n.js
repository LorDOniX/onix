Framework.i18n = (function() {
	var i18n = function() {};

	/**
	 * All langs data.
	 *
	 * @private
	 * @type {Object}
	 * @memberof i18n
	 */
	i18n.prototype._langs = {};

	/**
	 * Current language
	 *
	 * @private
	 * @type {String}
	 * @memberof i18n
	 */
	i18n.prototype._currentLang = "";

	/**
	 * Add a new language
	 *
	 * @public
	 * @param {String} lang Language key
	 * @param {Object} data
	 * @memberof i18n
	 */
	i18n.prototype.addLanguage = function(lang, data) {
		this._langs[lang] = data;
	};

	/**
	 * Set new language by his key.
	 *
	 * @public
	 * @param {String} lang Language key
	 * @memberof i18n
	 */
	i18n.prototype.setLanguage = function(lang) {
		this._currentLang = lang;
	};

	/**
	 * Get text function. Translate for the current language and the key.
	 *
	 * @public
	 * @param  {String} key
	 * @return {String}    
	 * @memberof i18n
	 */
	i18n.prototype._ = function(key) {
		key = key || "";
		var lObj = this._langs[this._currentLang];
		var translate = "";

		if (lObj) {
			var parts = key.split(".");
			var len = parts.length;

			parts.every(function(item, ind) {
				if (item in lObj) {
					lObj = lObj[item];

					if (ind == len - 1) {
						translate = lObj;
						return false;
					}
				}
				else return false;

				// go on
				return true;
			});
		}

		return translate;
	};

	/**
	 * Load language from the file.
	 *
	 * @public
	 * @param  {String} lang Language key
	 * @param  {String} url  Path to the file
	 * @return {Framework.Promise}
	 * @memberof i18n
	 */
	i18n.prototype.loadLanguage = function(lang, url) {
		var promise = Framework.Promise.defer();

		Framework.HTTP.createRequest({
			url: url
		}).then(function(data) {
			this.addLanguage(lang, data.data);
			promise.resolve();
		}.bind(this), function(data) {
			promise.resolve();
		});

		return promise;
	};

	var i18nInstance = new i18n();

	// bind _ for language
	window._ = i18nInstance._.bind(i18nInstance);

	return i18nInstance;
})();
