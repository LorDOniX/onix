Framework.Route = (function() {
	var Route = function() {};

	/**
	 * All routes
	 *
	 * @private
	 * @type {Array}
	 * @memberof Route
	 */
	Route.prototype._routes = [];

	/**
	 * Otherwise route
	 *
	 * @private
	 * @type {Object}
	 * @memberof Route
	 */
	Route.prototype._otherwise = null;

	/**
	 * Add route to the router.
	 *
	 * @public
	 * @param  {String} url 
	 * @param  {Object} config
	 * @return {Himself}
	 * @memberof Route
	 */
	Route.prototype.when = function(url, config) {
		this._routes.push({
			url: url,
			config: config
		});

		return this;
	};

	/**
	 * Otherwise.
	 *
	 * @public
	 * @param  {String} page
	 * @param  {Object} config
	 * @return {Himself}
	 * @memberof Route
	 */
	Route.prototype.otherwise = function(config) {
		this._otherwise = {
			config: config
		};

		return this;
	};

	/**
	 * Route GO.
	 *
	 * @public
	 * @memberof Route
	 */
	Route.prototype.go = function() {
		var path = Framework.Location.get();
		var find = false;
		var config = null;
		var data = {};

		this._routes.every(function(item) {
			if (path.match(new RegExp(item.url))) {
				config = item.config;
				find = true;
				
				return false;
			}
			else {
				return true;
			}
		});

		if (!find && this._otherwise) {
			config = this._otherwise.config;
		}

		if (config) {
			var contr = null;

			Object.keys(config).forEach(function(key) {
				var value = config[key];

				switch (key) {
					case "controller":
						contr = value;
						break;
				}
			});

			// run controller
			if (contr) {
				contr();
			}
		}
	};

	return new Route();
})();
