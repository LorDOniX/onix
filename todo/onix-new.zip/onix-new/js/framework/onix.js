onix = (function() {
	/**
	 * Module/app types
	 * @const
	 */
	var TYPES = {
		SERVICE: 1,
		FACTORY: 2,
		CONSTANT: 3,
		RUN: 4
	};

	/**
	 * $$module item
	 * @class $$module
	 * 
	 */
	var $$module = function() {
		this._allObj = [];
	};

	/**
	 * Add a new service
	 *
	 * @public
	 * @param  {String} name
	 * @param  {Array|Function} param With DI
	 * @memberof $$module
	 */
	$$module.prototype.service = function(name, param) {
		this._allObj.push({
			name: name,
			param: param,
			type: TYPES.SERVICE
		});
	};

	/**
	 * Add a new factory
	 *
	 * @public
	 * @param  {String} name
	 * @param  {Array|Function} param With DI
	 * @memberof $$module
	 */
	$$module.prototype.factory = function(name, param) {
		this._allObj.push({
			name: name,
			param: param,
			type: TYPES.FACTORY
		});
	};

	/**
	 * Add new constant
	 * 
	 * @public
	 * @param  {String} name
	 * @param  {Object} param
	 * @memberof onix
	 */
	$$module.prototype.constant = function(name, obj) {
		this._allObj.push({
			name: name,
			param: obj,
			type: TYPES.CONSTANT
		});
	};

	/**
	 * Add a new run
	 * 
	 * @public
	 * @param  {Array|Function} param With DI
	 * @memberof $$module
	 */
	$$module.prototype.run = function(param) {
		this._allObj.push({
			param: param,
			type: TYPES.RUN
		});
	};

	/**
	 * Read/add a config
	 * 
	 * @public
	 * @param  {Object|String} obj
	 * @memberof $$module
	 */
	$$module.prototype.config = function(obj) {
		// read/write ?
		var o = onix.config(obj);

		// if read -> return output o
		if (o) {
			return o;
		}
	};

	/**
	 * Get all objects in the module.
	 * 
	 * @public
	 * @return {Object}
	 * @memberof $$module
	 */
	$$module.prototype.getAllObjects = function() {
		return this._allObj;
	};

	/**
	 * Dependency injection
	 *
	 * @class $$inject
	 */
	var $$inject = function(allObjects) {
		this._objects = allObjects;
	};

	/**
	 * Dependency injection bind
	 *
	 * @private
	 * @param  {Function|Array} param
	 * @param  {Object} [replace]
	 * @return {Object}
	 * @memberof $$inject
	 */
	$$inject.prototype.bind = function(param, replace) {
		var fn;
		var args = [];

		replace = replace || {};

		if (Array.isArray(param)) {
			param.every(function(item) {
				if (typeof item === "function") {
					fn = item;
					return false;
				}
				else {
					args.push(item in replace ? replace[item] : this._objects[item]);
				}

				return true;
			}, this);
		}
		else {
			fn = param;
		}

		/**
		 * Run new binded function - with the new
		 * @param  {Function|Object} [scope] 
		 * @param  {Boolean} [callWithNew] 
		 * @return {Function}
		 */
		return function(scope, callWithNew) {
			if (callWithNew) {
				var obj = Object.create(fn.prototype);
				fn.apply(obj, args);
				return obj;
			}
			else {
				return fn.apply(scope || fn, args);
			}
		};
	};

	/**
	 * Main framework object.
	 * 
	 * @class onix
	 */
	var onix = {
		/**
		 * All objects
		 *
		 * @private
		 * @type {Array}
		 * @memberof onix
		 */
		_allObj: [],

		/**
		 * All processed objects
		 *
		 * @private
		 * @type {Object}
		 * @memberof onix
		 */
		_objects: {},

		/**
		 * All modules
		 *
		 * @private
		 * @type {Object}
		 * @memberof onix
		 */
		_modules: {},

		/**
		 * Config name
		 *
		 * @private
		 * @const
		 * @memberof onix
		 */
		_CONFIG_NAME: "$config",

		/**
		 * DI name
		 *
		 * @private
		 * @const
		 * @memberof onix
		 */
		_DI_NAME: "$inject",

		/**
		 * Init function
		 *
		 * @private
		 * @memberof onix
		 */
		_init: function() {
			// pred DOM loadem
			this._objects[this._CONFIG_NAME] = {};

			document.addEventListener("DOMContentLoaded", this._domLoad.bind(this));
		},

		/**
		 * Event - Dom LOAD
		 *
		 * @private
		 * @memberof onix
		 */
		_domLoad: function() {
			// create DI
			var $inject = new $$inject(this._objects);

			this._objects[this._DI_NAME] = $inject;

			// process all inner items
			this._allObj.forEach(function(item) {
				// only 2 types
				switch (item.type) {
					case TYPES.SERVICE:
						this._objects[item.name] = $inject.bind(item.param)(null, true);
						break;

					case TYPES.FACTORY:
						this._objects[item.name] = $inject.bind(item.param)();
						break;
				}
			}, this);

			// delete them
			this._allObj.length = 0;

			var runs = [];

			// process all modules
			Object.keys(this._modules).forEach(function(moduleName) {
				var module = this._modules[moduleName].module;

				module.getAllObjects().forEach(function(moduleItem) {
					// modules have more types
					switch (moduleItem.type) {
						case TYPES.SERVICE:
							this._objects[moduleItem.name] = $inject.bind(moduleItem.param)(null, true);
							break;

						case TYPES.FACTORY:
							this._objects[moduleItem.name] = $inject.bind(moduleItem.param)();
							break;

						case TYPES.CONSTANT:
							this._objects[moduleItem.name] = moduleItem.param;
							break;

						case TYPES.RUN:
							runs.push(moduleItem);
							break;
					}
				}, this);
			}, this);

			// onix main run
			$inject.bind(this._run)(this);

			// run all runs
			runs.forEach(function(run) {
				$inject.bind(run.param)();
			});
		},

		/**
		 * Main access point in the framework
		 *
		 * @private
		 * @memberof onix
		 */
		_run: [
			"$i18n",
			"$template",
			"$loader",
			"$route",
			"$myQuery",
		function(
			$i18n,
			$template,
			$loader,
			$route,
			$myQuery
		) {
			// binds
			this.element = function(value, parent) {
				return new $myQuery.get(value, parent);
			};

			// inits
			$loader.init();
			$route.init();
			$template.init();

			// language
			window._ = $i18n._.bind($i18n);
		}],

		/**
		 * Read/add config to the onix application.
		 *
		 * @public
		 * @param  {Object|String} obj
		 * @memberof onix
		 */
		config: function(obj) {
			if (typeof obj === "string") {
				// obj is key
				return this._objects[this._CONFIG_NAME][obj];
			}
			else if (typeof obj === "object") {
				Object.keys(obj).forEach(function(key) {
					this._objects[this._CONFIG_NAME][key] = obj[key];
				}.bind(this));
			}
		},

		/**
		 * Add service to the application.
		 *
		 * @public
		 * @param  {String} name 
		 * @param  {Function|Array} param
		 * @memberof onix
		 */
		service: function(name, param) {
			this._allObj.push({
				name: name,
				param: param,
				type: TYPES.SERVICE
			});
		},

		/**
		 * Add factory to the application.
		 *
		 * @public
		 * @param  {String} name 
		 * @param  {Function|Array} param
		 * @memberof onix
		 */
		factory: function(name, param) {
			this._allObj.push({
				name: name,
				param: param,
				type: TYPES.FACTORY
			});
		},

		/**
		 * Add module to the application.
		 *
		 * @public
		 * @param  {String} name 
		 * @return {$$module}
		 * @memberof onix
		 */
		module: function(name) {
			var module = new $$module();

			this._modules[name] = {
				module: module
			};

			return module;
		},

		/**
		 * Get object
		 *
		 * @public
		 * @param  {String} name
		 * @return {Function|Object} 
		 * @memberof onix
		 */
		getObject: function(name) {
			name = name || "";

			return this._objects[name];
		},

		/**
		 * Get all objects
		 *
		 * @public
		 * @return {Object}
		 * @memberof onix
		 */
		getAllObjects: function() {
			return this._objects;
		},

		/**
		 * Empty function
		 *
		 * @public
		 * @memberof onix
		 */
		noop: function() {

		},

		/**
		 * Framework info.
		 *
		 * @public
		 * @memberof onix
		 */
		info: function() {
			console.log(
				"Onix JS Framework\n" +
				"Version: 2.1.1\n" +
				"Date: 16. 12. 2015"
			);
		}
	};

	// init app
	onix._init();

	return onix;
})();


/**
 * Main framework configuration
 * @class CONFIG
 */
onix.config({
	/**
	 * Template delimiter
	 *
	 * @public
	 * @type {Object}
	 * @memberof CONFIG
	 */
	TMPL_DELIMITER: {
		LEFT: "{{",
		RIGHT: "}}"
	}
});
