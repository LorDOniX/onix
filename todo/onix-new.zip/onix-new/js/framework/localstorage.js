Framework.Storage = (function() {
	var Storage = function() {
		this._disable = !("localStorage" in window);
	};

	Storage.prototype.set = function(key, value) {
		if (this._disable || !key) return;

		localStorage.setItem(key, value);
	};

	Storage.prototype.get = function(key) {
		if (this._disable || !key) return null;

		return localStorage.getItem(key);
	};

	Storage.prototype.remove = function(key) {
		if (this._disable || !key) return null;

		return localStorage.removeItem(key);
	};

	return new Storage();
})();
