/**
 * Main class for select.
 *
 * @class Select
 * @param {NodeElement} el Where element has class "dropdown"
 */
Framework.Select = function(el) {
	// extend our class
	Framework.Common.extend(this, Framework.Event);

	this._CONST = {
		CAPTION_SEL: ".dropdown-toggle",
		OPTIONS_SEL: ".dropdown-menu a",
		OPEN_DROPDOWN_SEL: ".dropdown.open",
		OPEN_CLASS: "open",
		ACTIVE_CLASS: "active"
	};

	this._el = el;

	this._bind(el);
};

/**
 * Bind clicks on the select.
 *
 * @private
 * @param {NodeElement} el Where element has class "dropdown"
 * @memberof Select
 */
Framework.Select.prototype._bind = function(el) {
	var captionEl = el.querySelector(this._CONST.CAPTION_SEL);
	var con = this._CONST;

	// click on the caption
	captionEl.addEventListener("click", function(e) {
		e.stopPropagation();

		var isOpen = el.classList.contains(con.OPEN_CLASS);

		var removeAllOpened = function() {
			// remove all
			Framework.MyQuery.get(con.OPEN_DROPDOWN_SEL).forEach(function(item) {
				item.classList.remove("open");
			});
		};

		var clickFn = function(e) {
			removeAllOpened();
			window.removeEventListener("click", clickFn);
		};

		removeAllOpened();

		if (isOpen) {
			// outside click
			window.removeEventListener("click", clickFn);
		}
		else {
			// outside click
			window.addEventListener("click", clickFn);

			el.classList.add(con.OPEN_CLASS);
		}
	});

	Framework.MyQuery.get(this._CONST.OPTIONS_SEL, el).forEach(function(option) {
		option.addEventListener("click", Framework.Common.bindWithoutScope(function(e, scope) {
			e.stopPropagation();

			if (!this.parentNode.classList.contains(con.ACTIVE_CLASS)) {
				// remove previously selected
				this.parentNode.parentNode.querySelector("." + con.ACTIVE_CLASS).classList.remove(con.ACTIVE_CLASS);

				// add to the current
				this.parentNode.classList.add(con.ACTIVE_CLASS);

				el.classList.remove(con.OPEN_CLASS);

				// trigger click
				var value = this.getAttribute("data-value") || "";
				scope.trigger("change", value);
			}
		}, this));
	}, this);
};
