let A = require("./a");

new A.rom();

console.log("c.js");

setTimeout(() => {
	console.log("iti");
}, 500);

class Events {
	constructor() {
		this._pole = [];
		console.log("Events const");
	}
};

class Roman extends Events {
	constructor() {
		super();
		console.log("roman const");
	}

	prirad() {
		this._pole.push("polozka");
	}
};

var ri = new Roman();
ri.prirad();
ri.prirad();

var rom = new Roman();
rom.prirad();

console.log(ri._pole)
console.log(rom._pole)
