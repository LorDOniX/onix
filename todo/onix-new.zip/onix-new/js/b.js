class B {
	getB() {
		return "B";
	}
};

module.exports = B;
