let B = require("./b");

class A {
	getA () {
		return "A";
	}

	brr() {
		console.log("brr");
	}

	static rom() {
		let x = new B();
		console.log(x.getB());
	}
};

module.exports = A;
