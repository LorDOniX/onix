'use strict';

var gulp = require('gulp');
var uglify = require('gulp-uglify');
var watchify = require('watchify');
var browserify = require('browserify');
var source = require('vinyl-source-stream');
var buffer = require('vinyl-buffer');
var gutil = require('gulp-util');
var sourcemaps = require('gulp-sourcemaps');
var less = require('gulp-less');
var minifyCSS = require('gulp-minify-css');
var streamify = require('gulp-streamify');
var assign = require('lodash.assign');

/* ****************** nastaveni *************************************/

var files = require('./files.json');

var MY_CONST = {
	BUNDLE_JS: 'main.js',
	BUNDLE_DIST_JS: 'main-min.js',
	BUNDLE_FOLDER: "./static/js",
	SOURCE_LESS: './less',
	LESS_FILE: './less/main.less',
	TARGET_CSS: './static/css'
};

// add custom browserify options here
var customOptsDev = {
	entries: files.files,
	debug: true
};

var opts = assign({}, watchify.args, customOptsDev);
opts.ignore = ["./js/framework/polyfills.js"];
opts.noParse = [
	require.resolve('./js/framework/polyfills.js')
];

var b = watchify(browserify(opts));

b.on('update', bundleDev);
b.on('log', gutil.log);
b.transform("babelify", {presets: ["es2015"]});

function bundleDev() {
	return b.bundle()
		.on('error', (err) => {
			console.log("Error: " + err.message);
		})
		.pipe(source(MY_CONST.BUNDLE_JS))
		.pipe(buffer())
		.pipe(sourcemaps.init({loadMaps: true}))
		.pipe(sourcemaps.write('./'))
		.pipe(gulp.dest(MY_CONST.BUNDLE_FOLDER));
}

function bundeDist() {
	let bDist = browserify({
		entries: files.files
	});
	bDist.transform("babelify", {presets: ["es2015"]});

	return bDist.bundle()
		.on('error', (err) => {
			console.log("Error: " + err.message);
		})
		.pipe(source(MY_CONST.BUNDLE_DIST_JS))
		.pipe(streamify(uglify()))
		.pipe(gulp.dest(MY_CONST.BUNDLE_FOLDER));
}

/* ****************** tasky *************************************/

gulp.task('less', function () {
	return gulp.src([MY_CONST.LESS_FILE])
		.pipe(less().on('error', (err) => {
			console.log("less error: " + err);
		}))
		.pipe(gulp.dest(MY_CONST.TARGET_CSS))
});

gulp.task('watch', function() {
	gulp.watch(MY_CONST.SOURCE_LESS + '/*.less', ['less']);
});

gulp.task('lessDist', function () {
	return gulp.src([MY_CONST.LESS_FILE])
		.pipe(less({compress: true}).on('error', (err) => {
			console.log("less error: " + err);
		}))
		.pipe(minifyCSS({keepBreaks: false, compatibility: 'ie8'}))
		.pipe(gulp.dest(MY_CONST.TARGET_CSS))
});

gulp.task('js', bundleDev);
gulp.task('jsDist', bundeDist);
gulp.task('dist', ['jsDist', 'lessDist']);
gulp.task('default', ['js', 'less', 'watch']);
