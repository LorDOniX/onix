Stitcherweb.TourListPage = Stitcherweb.Page.create();

// ------------------------ private ---------------------------------------

/**
 * After init create pagination.
 */
Stitcherweb.TourListPage._afterInit = function() {
	this._createPagination();

	// dropdowns
	var orderSelect = new Framework.Select(this._getEl("orderSelect"));

	orderSelect.on("change", function(value) {
		this._selectChange("order", value);
	}, this);

	var filterSelect = new Framework.Select(this._getEl("filterSelect"));

	filterSelect.on("change", function(value) {
		this._selectChange("filter", value);
	}, this);
};

/**
 * Create pagination.
 */
Stitcherweb.TourListPage._createPagination = function() {
	var conf = this._getConfig();
	var page = conf.page;
	var pages = conf.page_count;
	var COUNT = 4;

	var interval = [
		page - COUNT,
		page + COUNT
	];

	interval[0] = interval[0] < 1 ? 1 : interval[0];
	interval[1] = interval[1] > pages ? pages : interval[1];

	if (pages > 1) {
		var pagination = [];

		if (interval[0] > 1) {
			pagination.push(this._getPaginationItem({
				page: 1,
				title: _("tour.first_page")
			}));
		}

		for (var i = interval[0]; i <= interval[1]; i++) {
			pagination.push(this._getPaginationItem({
				page: i,
				active: i == page
			}));
		}

		if (interval[1] < pages) {
			pagination.push(this._getPaginationItem({
				page: pages,
				title: "... " + pages
			}));
		}

		Framework.MyQuery.get(this._getEl("pagination")).empty().append(Framework.DOM.create({
			el: "ul",
			"class": "pagination",
			child: pagination
		}));
	}
};

/**
 * One pagination item.
 * @param  {Object} conf
 * @return {DOMElement}
 */
Stitcherweb.TourListPage._getPaginationItem = function(conf) {
	var newPage = {
		el: "li",
		child: [{
			el: "a",
			innerHTML: conf.title || conf.page
		}]
	};

	var href = "";

	if (conf.active) {
		newPage["class"] = "active";
		href = "javascript:void(0)";
	}
	else {
		var search = Framework.Location.search();
		search["page"] = conf.page;
		href = Framework.Location.createSearchURL(search);
	}

	newPage.child[0].attrs = {
		href: href
	};

	return newPage;
};

/**
 * Select change
 * @param  {String} key  
 * @param  {String} value
 */
Stitcherweb.TourListPage._selectChange = function(key, value) {
	var search = Framework.Location.search();

	search[key] = value;
	Framework.Location.search(search);
};

// ------------------------ public ----------------------------------------

/**
 * Event - new tour
 */
Stitcherweb.TourListPage.newTour = function() {
	var tourName = (this._getEl("tourName").value || "").trim();
	var notify = Framework.Notify.get(this._getEl("alert")).reset();

	if (!tourName.length) {
		notify.error(_("tour.error"));
	}
	else {
		var postData = {
			name: tourName,
			owner: this._getConfig().user
		};

		Stitcherweb.TourResource.newTour(postData).then(function(data) {
			notify.ok(_("tour.create")).hide().then(function() {
				Framework.Location.refresh();
			});
		}, function(data) {
			notify.error(_("tour.create_error"));
		});
	}
};

/**
 * Event - delete tour
 * @param  {Number} id Tour id
 */
Stitcherweb.TourListPage.deleteTour = function(id) {
	var notify = Framework.Notify.get(this._getEl("listAlert")).reset();

	Framework.Common.confirm(_("tour.delete_confirm")).then(function() { 
		Stitcherweb.TourResource.remove(id).then(function() {
			notify.ok(_("tour.delete")).hide().then(function() {
				Framework.Location.refresh();
			});
		}, function() {
			notify.error(_("tour.delete_error"));
		});
	});
};

/**
 * Order by - blue down arror next to the table captions
 * @param  {String} orderKey
 */
Stitcherweb.TourListPage.orderBy = function(orderKey) {
	this._selectChange("order", orderKey);
};
