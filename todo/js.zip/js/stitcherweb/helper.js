Stitcherweb.Helper = (function() {
	var Helper = function() {};

	// ------------------------ private ----------------------------------------
	
	/**
	 * CSRF token value
	 * @type {String}
	 */
	Helper.prototype._TOKEN_NAME = "csrftoken";
	
	// ------------------------ public ----------------------------------------
	
	/**
	 * Get panorama state.
	 * @param  {StringEnum} state
	 * @return {String}
	 */
	Helper.prototype.getPanoramaState = function(state) {
		var stateDesc = "";

		switch (state) {
			case "N": stateDesc = _("panorama_states.n"); break;
			case "U": stateDesc = _("panorama_states.u"); break;
			case "P": stateDesc = _("panorama_states.p"); break;
			case "S": stateDesc = _("panorama_states.s"); break;
			case "A": stateDesc = _("panorama_states.a"); break;
			case "E": stateDesc = _("panorama_states.e"); break;
		};

		return stateDesc;
	};

	/**
	 * Get CSRF token header
	 * @return {Object}
	 */
	Helper.prototype.getCSRFheader = function() {
		return {
			type: "X-CSRFToken",
			value: Framework.Common.getCookie(this._TOKEN_NAME)
		};
	};

	/**
	 * Handle error message.
	 * @param  {Object} response
	 * @return {String}
	 */
	Helper.prototype.handleErrorMsg = function(response) {
		if (response.status == 403) {
			return _("error.403");
		}
		else if (typeof response.data === "string") {
			return response.data;
		}
		else if (typeof response.data === "object") {
			return JSON.stringify(response.data);
		}
		else {
			return _("error.default");
		}
	};

	return new Helper();
})();
