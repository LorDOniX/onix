Stitcherweb.TourResource = (function() {
	// ------------------------ private ---------------------------------------
	
	var TourResource = function() {};
	
	/**
	 * Base url.
	 * @type {String}
	 */
	TourResource.prototype._baseURL = Stitcherweb.URLS.TOURS;

	// ------------------------ public ----------------------------------------

	/**
	 * Remove one tour.
	 * @param  {Number} id
	 * @return {Promise}
	 */
	TourResource.prototype.remove = function(id) {
		id = id || 1;

		return Framework.HTTP.createRequest({
			method: Framework.HTTP.METHOD.DELETE,
			url: this._baseURL + id,
			headers: [
				Stitcherweb.Helper.getCSRFheader()
			]
		});
	};

	/**
	 * Create new tour.
	 * @param  {Object} postData
	 * @return {Promise}
	 */
	TourResource.prototype.newTour = function(postData) {
		return Framework.HTTP.createRequest({
			method: Framework.HTTP.METHOD.POST, 
			url: this._baseURL,
			postData: postData,
			headers: [
				Stitcherweb.Helper.getCSRFheader()
			]
		});
	};

	/**
	 * Update tour.
	 * @param  {Number} id
	 * @param  {Object} postData
	 * @return {Promise}
	 */
	TourResource.prototype.updateTour = function(id, postData) {
		return Framework.HTTP.createRequest({
			method: Framework.HTTP.METHOD.PATCH,
			url: this._baseURL + id + "/",
			postData: postData,
			headers: [
				Stitcherweb.Helper.getCSRFheader()
			]
		});
	};

	/**
	 * Send tour to editor
	 * @param  {Number} id
	 * @return {Promise}
	 */
	TourResource.prototype.sendTour = function(id) {
		return Framework.HTTP.createRequest({
			method: Framework.HTTP.METHOD.POST, 
			url: this._baseURL + id + "/send/",
			headers: [
				Stitcherweb.Helper.getCSRFheader()
			]
		});
	};

	/**
	 * Approve tour by editor
	 * @param  {Number} id
	 * @param  {Object} postData
	 * @return {Promise}
	 */
	TourResource.prototype.approveTour = function(id, postData) {
		return Framework.HTTP.createRequest({
			method: Framework.HTTP.METHOD.POST, 
			url: this._baseURL + id + "/approve/",
			postData: postData,
			headers: [
				Stitcherweb.Helper.getCSRFheader()
			]
		});
	};

	/**
	 * Remove tour by editor
	 * @param  {Number} id
	 * @param  {Object} postData
	 * @return {Promise}
	 */
	TourResource.prototype.rejectTour = function(id, postData) {
		return Framework.HTTP.createRequest({
			method: Framework.HTTP.METHOD.POST, 
			url: this._baseURL + id + "/reject/",
			postData: postData,
			headers: [
				Stitcherweb.Helper.getCSRFheader()
			]
		});
	};

	/**
	 * Get all panoramas in the tour
	 * @param  {Number} id
	 * @return {Promise}
	 */
	TourResource.prototype.getPanoramas = function(id) {
		return Framework.HTTP.createRequest({
			url: this._baseURL + id + "/panoramas"
		});
	};

	return new TourResource();
})();
