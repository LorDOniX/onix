Stitcherweb.PanoramaResource = (function() {
	// ------------------------ private ---------------------------------------
	
	var PanoramaResource = function() {};
	
	/**
	 * Base URL.
	 * @type {String}
	 */
	PanoramaResource.prototype._baseURL = Stitcherweb.URLS.PANORAMAS;
	
	// ------------------------ public ----------------------------------------

	/**
	 * Remove one panorama
	 * @param  {Number} id
	 * @return {Promise}
	 */
	PanoramaResource.prototype.remove = function(id) {
		id = id || 1;

		return Framework.HTTP.createRequest({
			method: Framework.HTTP.METHOD.DELETE,
			url: this._baseURL + id,
			headers: [
				Stitcherweb.Helper.getCSRFheader()
			]
		});
	};

	/**
	 * Blur image
	 * @param  {Number} id
	 * @param  {Object} postData
	 * @return {Promise}
	 */
	PanoramaResource.prototype.blurImage = function(id, postData) {
		id = id || 1;

		return Framework.HTTP.createRequest({
			method: Framework.HTTP.METHOD.POST,
			postData: postData,
			url: this._baseURL + id + "/blur/",
			headers: [
				Stitcherweb.Helper.getCSRFheader()
			]
		});
	};

	/**
	 * Update panorama detail
	 * @param  {Number} id
	 * @param  {Object} postData
	 * @return {Promise}
	 */
	PanoramaResource.prototype.updatePanorama = function(id, postData) {
		id = id || 1;
		
		return Framework.HTTP.createRequest({
			method: Framework.HTTP.METHOD.PATCH,
			url: this._baseURL + id + "/",
			postData: postData,
			headers: [
				Stitcherweb.Helper.getCSRFheader()
			]
		});
	};

	/**
	 * Stitched - progress of places; getData is array of ids
	 * @param  {Array} getData
	 * @return {Promise}
	 */
	PanoramaResource.prototype.stitched = function(getData) {
		return Framework.HTTP.createRequest({
			url: this._baseURL + "stitched/",
			getData: getData
		});
	};

	/**
	 * Stitched - setPreset new ID.
	 * @param  {Number} id
	 * @param  {Object} postData
	 * @return {Promise}
	 */
	PanoramaResource.prototype.setPreset = function(id, postData) {
		return Framework.HTTP.createRequest({
			method: Framework.HTTP.METHOD.POST,
			url: this._baseURL + id + "/setPreset/",
			postType: Framework.HTTP.POST_TYPES.FORM_DATA,
			postData: postData,
			headers: [
				Stitcherweb.Helper.getCSRFheader()
			]
		});
	};

	return new PanoramaResource();
})();
