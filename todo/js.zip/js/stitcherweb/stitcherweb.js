// APP Stitcherweb main object
Stitcherweb = (function() {
	var Stitcherweb = {
		_config: {},

		_binds: {},

		// for Page - detail css selector
		DETAIL_SEL: ".detail",

		// app resource URLs
		URLS: {
			UPLOAD: "/upload/",
			PANORAMAS: "/api/panoramas/",
			TOURS: "/api/tours/"
		},

		DEBUG_IMG_SERVER: "http://zuza.dev:9000",

		// controller for list page
		_tourListPageController: function() {
			var config = this._config.TMPL_DATA || {};

			Stitcherweb.TourListPage.setConfig(config);
			Stitcherweb.TourListPage.init();
		},

		// controller for detail page
		_tourDetailPageController: function() {
			var config = this._config.TMPL_DATA || {};

			Stitcherweb.TourDetailPage.setConfig(config);
			Stitcherweb.TourDetailPage.init();
		},

		// application init
		init: function() {
			this._binds.tourListPageController = this._tourListPageController.bind(this);
			this._binds.tourDetailPageController = this._tourDetailPageController.bind(this);

			Framework.i18n.setLanguage("cs");

			Framework.Route
				.when("/tour/[1-9]+", {
					controller: this._binds.tourDetailPageController
				})
				.when("/", {
					controller: this._binds.tourListPageController
				})
				.otherwise({
					controller: this._binds.tourListPageController
				});

			// load language - after promise resolve, app will start
			Framework.i18n.loadLanguage("cs", "/static/js/locale/cs.json").then(function() {
				Framework.Route.go();
			});
		},

		// cfg {Object}
		setConfig: function(cfg) {
			this._config = cfg;
		},

		// value {String}
		getConfig: function(value) {
			var cfg = this._config || {};

			return cfg[value || ""];
		}
	};

	// bind dom ready
	Framework.on("dom-ready", Stitcherweb.init, Stitcherweb);

	return Stitcherweb;
})();
