Stitcherweb.UploadSnippet = Stitcherweb.Snippet.create();

// ------------------------ private ---------------------------------------

/**
 * From the template creates add new place snippet.
 * @param  {Object} config
 * @return {NodeElement} root element
 */
Stitcherweb.UploadSnippet._create = function(config) {
	var root = Framework.DOM.create({
		el: "div",
		"class": "upload-snippet",
		innerHTML: Framework.Template.get("addPlaceTmpl")
	});

	this._setName("add-place");

	this._const = {
		SHOW_PREVIEWS_KEY: "SHOW_PREVIEWS",
		HIDE_CLASS: "hide"
	};

	return root;
};

/**
 * Setup snippet.
 */
Stitcherweb.UploadSnippet._setup = function() {
	this._notify = Framework.Notify.get(this._getEl("alert"));
	this._notify.info(_("add_place.info"));

	// dropdown
	var dropdownEl = this._getEl("presetSelect");
	this._presetSelect = new Framework.Select(dropdownEl, {
		addCaption: true
	});
	this._presetSelect.on("change", this._presetChange, this);

	this._presetID = null;
	this._setPresets();
};

/**
 * On activate
 */
Stitcherweb.UploadSnippet._activate = function() {
	this.on("tour-state-update", this._tourStateUpdate, this);

	this._updateShowPreviews();
};

/**
 * On deactivate
 */
Stitcherweb.UploadSnippet._deactivate = function() {
	this.off("tour-state-update", this._tourStateUpdate);
};

/**
 * Event - tour-state-update
 * @param  {Boolean} disabled
 */
Stitcherweb.UploadSnippet._tourStateUpdate = function(disabled) {
	// admin - do not disable anything
	if (Stitcherweb.getConfig("USER_IS_ADMIN")) {
		return;
	}
	
	this._getEl("uploadBtn").disabled = disabled;
};

/**
 * Update checkbox state for show previews.
 */
Stitcherweb.UploadSnippet._updateShowPreviews = function() {
	var chbx = this._getEl("showPreviews");

	if (Framework.Storage.get(this._const.SHOW_PREVIEWS_KEY)) {
		chbx.checked = true;
	}
	else {
		chbx.checked = false;
	}
};

/**
 * Select preset - by count {number}
 */
Stitcherweb.UploadSnippet._setPresets = function(count) {
	count = count || 0;

	var dropdownEl = this._getEl("presetSelect");
	var presets = this._getConfig().presets;
	var find = null;

	this._presetID = null;

	Object.keys(presets).every(function(presetsCount) {
		if (presetsCount == count) {
			find = presets[presetsCount];
			return false;
		}
		else return true;
	});

	if (find) {
		var outputEl = this._getEl("presetValues");

		dropdownEl.classList.remove(this._const.HIDE_CLASS);
		
		this._presetSelect.unbindChoices();
		
		outputEl.innerHTML = "";

		find.forEach(function(presetItem, ind) {
			var DOMobj = {
				el: "li",
				child: [{
					el: "a",
					href: "javascript:void(0)",
					innerHTML: presetItem.name,
					attrs: {
						"data-value": presetItem.id
					}
				}]
			};

			outputEl.appendChild(Framework.DOM.create(DOMobj));
		}, this);

		this._presetSelect.rebindChoices();
		this._presetSelect.selectOption(0);
	}
	else {
		dropdownEl.classList.add(this._const.HIDE_CLASS);
	}
};

/**
 * Change preset value - his ID.
 */
Stitcherweb.UploadSnippet._presetChange = function(value) {
	this._presetID = parseInt(value, 10);
};

// ------------------------ public ----------------------------------------

/**
 * Change in file input.
 */
Stitcherweb.UploadSnippet.uploadChange = function() {
	var files = this._getEl("uploadInput").files;
	var el = this._getEl("uploadPreviews");
	var count = Stitcherweb.UploadImages.getPicturesCount(files);

	this._setPresets(count);

	// show image previews
	if (Framework.Storage.get(this._const.SHOW_PREVIEWS_KEY)) {
		Stitcherweb.UploadImages.show(el, files);
	}
	else {
		el.innerHTML = "";
	}
};

/**
 * Upload photos
 */
Stitcherweb.UploadSnippet.upload = function() {
	var FILE_KEY = "file";
	var postData = [];
	var files = this._getEl("uploadInput").files;

	this._notify.reset();

	Framework.Common.nodesForEach(files, function(file) {
		postData.push({
			name: FILE_KEY,
			value: file
		});
	});

	if (this._presetID != null && postData.length) {
		postData.push({
			name: "tour",
			value: this._getConfig().id
		});

		postData.push({
			name: "presetId",
			value: this._presetID
		});

		Framework.Loader.start();

		Stitcherweb.UploadResource.upload(postData).then(function(data) {
			Framework.Loader.end();

			this._notify.ok(_("add_place.upload_done")).hide();

			// reset
			this._getEl("uploadInput").value = "";
			this._getEl("uploadPreviews").innerHTML = "";

			this._setPresets();

			this._getParent().trigger("place-add", data);
		}.bind(this), function(data) {
			Framework.Loader.end();

			this._notify.error(Stitcherweb.Helper.handleErrorMsg(data));
		}.bind(this));
	}
	else if (this._presetID != null) {
		this._notify.error(_("add_place.upload_no_preset", {
			count: Stitcherweb.UploadImages.getPicturesCount(files)
		}));
	}
	else {
		this._notify.error(_("add_place.upload_no_photo"));
	}
};

/**
 * Is snippet changed? Return false - we do not need to test it
 * @return {Boolean}
 */
Stitcherweb.UploadSnippet.isChanged = function() {
	return false;
};

/**
 * Checkbox - show previews change
 */
Stitcherweb.UploadSnippet.showPreviewChange = function() {
	if (Framework.Storage.get(this._const.SHOW_PREVIEWS_KEY)) {
		Framework.Storage.remove(this._const.SHOW_PREVIEWS_KEY);
	}
	else {
		Framework.Storage.set(this._const.SHOW_PREVIEWS_KEY, 1);
	}
};
