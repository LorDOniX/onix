Stitcherweb.TourDetailPage = Stitcherweb.Page.create();

// ------------------------ private ---------------------------------------

/**
 * After init - create map, bind events, select first place
 */
Stitcherweb.TourDetailPage._afterInit = function() {
	this._panoramaList = this._getConfig().panoramas || [];

	this._checkedIds = [];
	this._checkedIdsInterval = 5000;

	this._layoutWithMap = true;
	this._unloadInProgress = false;
	this._placesMissingParams = false;

	var mapEl = this._getEl("map");

	this._map = new Stitcherweb.Map(mapEl, this);
	this._map.createMarkers(this._panoramaList);
	this._panoramaID = null;
	this._currentSnippet = null;
	this._search = new Stitcherweb.Search(this._map, this._getEl("search-results"));

	// events
	this.on("place-add", this._addPlace, this);
	this.on("place-remove", this._deletePlace, this);
	this.on("place-save", this._placeSave, this);
	this.on("preset-change", this._presetChange, this);
	this.on("marker-update", this._markerUpdate, this);
	this.on("layout-change", this._layoutChange, this);
	window.addEventListener("beforeunload", this._beforeUnload.bind(this));
	window.addEventListener("unload", this._unload.bind(this));

	// map events
	this._map.on("marker-click", this._markerClick.bind(this));

	// open first
	if (this._panoramaList.length) {
		this.editPlace(this._panoramaList[0].id);
	}

	// check for ids
	this._checkForIds();

	// update buttons disabled state
	this._tourStateAction();

	// update all places info
	this._updatePlacesInfo();
};

/**
 * Check for IDS - update their states
 */
Stitcherweb.TourDetailPage._checkForIds = function() {
	// for states U, P
	var ids = [];
	var request = [];
	
	// check states for IDS
	// TourDetailPage._panoramaList where IDS is uploading, stitching
	this._panoramaList.forEach(function(item) {
		// all U states
		if (item.state == "U" || item.state == "P") {
			ids.push(item.id);
			request.push({
				name: "id",
				value: item.id
			});
		}
	});

	this._checkedIds = ids;

	if (ids.length) {
		Stitcherweb.PanoramaResource.stitched(request).then(function(data) {
			// prijde 0-n hotovych ID -> pro zbyvajici zavolame znovu request
			data.data.forEach(function(item) {
				// update database
				this._panoramaList.forEach(function(place) {
					if (item.id == place.id) {
						this._updatePlace(place, item);
					}
				}, this);
			}, this);

			// call again
			setTimeout(this._checkForIds.bind(this), this._checkedIdsInterval);
		}.bind(this), function(data) {
			// call again
			setTimeout(this._checkForIds.bind(this), this._checkedIdsInterval);
		}.bind(this));
	}
};

/**
 * Update place.
 * @param  {Object} place   
 * @param  {Object} newPlace
 */
Stitcherweb.TourDetailPage._updatePlace = function(place, newPlace) {
	// update - data
	Framework.Common.extend(place, newPlace);

	var lineEl = Framework.DOM.get(".line[data-id='" + place.id + "'] .place-state");
	if (lineEl) {
		lineEl.innerHTML = Stitcherweb.Helper.getPanoramaState(place.state);
	}

	// update places info
	this._updatePlacesInfo();

	// propagate event to the snippet
	this.trigger("place-update", place);
};

/**
 * Set output - placeholder for add/edit place
 * @param {NodeElement} output
 * @param {Object} snippet Snippet object
 */
Stitcherweb.TourDetailPage._setOutput = function(output, snippet) {
	Framework.MyQuery.get(this._getEl("output")).empty().append(output);

	// setup snippet
	snippet.setup();

	// activate x deactivate snippet
	if (this._currentSnippet) {
		if (this._currentSnippet.getName() != snippet.getName()) {
			this._currentSnippet.deactivate();

			snippet.activate();

			this._currentSnippet = snippet;
		}
	}
	else {
		snippet.activate();

		this._currentSnippet = snippet;
	}

	// update status
	this._currentSnippet.trigger("tour-state-update", !this._isTourEditable());

	this._scrollToMainPart();
};

/**
 * Scroll page to the main part
 */
Stitcherweb.TourDetailPage._scrollToMainPart = function() {
	window.scrollTo(0, this._getEl("columnRight").offsetTop);
};

/**
 * Get panorama place by his id.
 * @param  {Number} id
 * @return {Object}   
 */
Stitcherweb.TourDetailPage._getPanoramaByID = function(id) {
	var panorama = null;

	this._panoramaList.every(function(item) {
		if (item.id == id) {
			panorama = item;
			return false;
		}
		else return true;
	});

	return panorama;
};

/**
 * Highlight current marker on map; also table with panoramas
 * @param  {Number} id
 */
Stitcherweb.TourDetailPage._activeMarker = function(id) {
	// map
	Framework.MyQuery.get(".animated-balloon.active, .line.active").forEach(function(node) {
		node.classList.remove("active");
	});

	if (id) {
		Framework.MyQuery.get(".animated-balloon[data-id='" + id + "'], .line[data-id='" + id + "']").forEach(function(node) {
			node.classList.add("active");
		});
	}

	this._map.updateDraggable(id);

	this._panoramaID = id;
};

/**
 * Event - map marker click
 * @param  {Number} id
 */
Stitcherweb.TourDetailPage._markerClick = function(id) {
	this.editPlace(id);
};

/**
 * Event - Marker update after the new one is created.
 * @param  {Object} fromPlace
 */
Stitcherweb.TourDetailPage._markerUpdate = function(fromPlace) {
	// update markers
	this._map.updateMarkers(this._panoramaList, true);
	this._activeMarker(fromPlace.id);
};

/**
 * Event - Add new place
 * @param {Object} data
 */
Stitcherweb.TourDetailPage._addPlace = function(data) {
	this._addPanoramaToList(data.data);

	// check for ids
	this._checkForIds();
};

/**
 * Event - delete place from edit place snippet
 * @param  {Number} id
 */
Stitcherweb.TourDetailPage._deletePlace = function(id) {
	this.deletePlace(id);
};

/**
 * Event - save place from edit place snippet
 * @param  {Object} data
 */
Stitcherweb.TourDetailPage._placeSave = function(data) {
	var currentPlace = this._getPanoramaByID(data.id);
	var editedPlace = data.place;

	// merge edited place with original one
	Object.keys(editedPlace).forEach(function(key) {
		currentPlace[key] = editedPlace[key];
	});

	this._updatePlacesInfo();
};

/**
 * Delete line with panorama place from table
 * @param  {Number} id
 */
Stitcherweb.TourDetailPage._deletePlaceFromTable = function(id) {
	// if it was uploaded - do not check this id
	var ind = this._checkedIds.indexOf(id);
	if (ind != -1) {
		this._checkedIds.splice(ind, 1);
	}

	var tableEl = this._getEl("placesList");
	var lineEl = Framework.DOM.get(".line[data-id='" + id + "']", tableEl);

	tableEl.removeChild(lineEl);

	// update table positions
	var panoLines = Framework.MyQuery.get(".line .panorama-pos");

	if (panoLines.len() > 0) {
		panoLines.forEach(function(el, ind) {
			el.innerHTML = ind + 1;
		});
	}
	else {
		// create empty l.tour_detail.pano_not_found
		tableEl.appendChild(Framework.DOM.create({ 
			el: "tr",
			child: [{
				el: "td",
				"class": "center",
				attrs: {
					colspan: 5
				},
				innerHTML: _("tour_detail.pano_not_found")
			}]
		}));
	}
};

/**
 * Add new place to panorama list
 * @param {Object} panoData
 */
Stitcherweb.TourDetailPage._addPanoramaToList = function(panoData) {
	this._panoramaList.push(panoData);

	// add new line to the table
	var tableEl = this._getEl("placesList");

	var newLine = Framework.DOM.create({
		el: "tr",
		"class": "line",
		attrs: {
			"data-id": panoData.id
		},
		innerHTML: Framework.Template.compile("panoramaListItem", {
			ID: panoData.id,
			POS: this._panoramaList.length,
			DESCRIPTION: panoData.description || _("tour_detail.pano_no_name"),
			STATE: Stitcherweb.Helper.getPanoramaState(panoData.state)
		})
	});

	// remove empty info
	if (this._panoramaList.length == 1) {
		Framework.MyQuery.get(tableEl).empty();
	}

	tableEl.appendChild(newLine);

	Framework.Template.bindTemplate(newLine, this);

	// update markers
	this._map.updateMarkers(this._panoramaList);

	// update places info
	this._updatePlacesInfo();
};

/**
 * Layout change from edit place snippet.
 * @param  {Object} data { map, [scroll]}
 */
Stitcherweb.TourDetailPage._layoutChange = function(data) {
	var isMap = data.map;

	if (isMap != this._layoutWithMap) {
		var left = this._getEl("columnLeft");
		var right = this._getEl("columnRight");

		if (isMap) {
			left.classList.remove("hide-column");
			right.classList.remove("col-md-12");
			right.classList.add("col-md-9");
		}
		else {
			left.classList.add("hide-column");
			right.classList.remove("col-md-9");
			right.classList.add("col-md-12");
		}
		
		this._layoutWithMap = isMap;

		if (data.scroll) {
			this._scrollToMainPart();
		}
	}
};

/**
 * Get tour data from the view.
 * @return {Object}
 */
Stitcherweb.TourDetailPage._getTourData = function() {
	return this._getConfig().tour;
};

/**
 * Is tour editable?
 * @return {Boolean}
 */
Stitcherweb.TourDetailPage._isTourEditable = function() {
	var state = this._getTourData().state;

	// new & rejected
	return state == "N" || state == "R";
};

/**
 * Set buttons disabled state according to tour state.
 */
Stitcherweb.TourDetailPage._tourStateAction = function() {
	// admin - do not disable anything
	if (Stitcherweb.getConfig("USER_IS_ADMIN")) {
		return;
	}

	// buttons
	var all = [
		this._getEl("sendTourBtn"),
		this._getEl("saveTourBtn"),
		this._getEl("addPlaceBtn"),
		this._getEl("addPlace2Btn")
	];

	var disabled = !this._isTourEditable();

	// disabled buttons for states - S, A
	all.forEach(function(el) {
		el.disabled = disabled;
	});

	// editors section
	var state = this._getTourData().state;
	var editorsDisable = state == "A";

	if (this._getEl("tourActionRejBtn") && this._getEl("tourActionAprBtn")) {
		this._getEl("tourActionRejBtn").disabled = editorsDisable;
		this._getEl("tourActionAprBtn").disabled = editorsDisable;
	}

	// process event to the snippet
	if (this._currentSnippet) {
		this._currentSnippet.trigger("tour-state-update", disabled);
	}
};

/**
 * Before page quit event.
 * @param  {UnloadEvent} e
 */
Stitcherweb.TourDetailPage._beforeUnload = function(e) {
	var change = false;

	// get current snippet for changes; admin - no restrictions, no admin - only editable tour
	if (this._currentSnippet && (Stitcherweb.getConfig("USER_IS_ADMIN") || this._isTourEditable())) {
		change = this._currentSnippet.isChanged();
	}

	if (change) {
		var e = e || window.event;
		var str = _("tour_detail.save_on_quit");

		// For IE and Firefox
		if (e) {
			e.returnValue = str;
		}

		setTimeout(function() {
			if (!this._unloadInProgress) {
				// process event to the snippet
				if (this._currentSnippet) {
					this._currentSnippet.trigger("show-save-info");
				}

				this._scrollToMainPart();
			}
		}.bind(this), 1);

		// For Safari
		return str;
	}
	else {
		return null;
	}
};

/**
 * Page is in unload state - will be destroyed
 */
Stitcherweb.TourDetailPage._unload = function() {
	this._unloadInProgress = true;
};

/**
 * Add class to tourState el.
 * @param {String} className
 */
Stitcherweb.TourDetailPage._addTourStateClass = function(className) {
	var el = this._getEl("tourState");

	if (el && className) {
		el.setAttribute("class", className);
	}
};

/**
 * Update places missing params info.
 */
Stitcherweb.TourDetailPage._updatePlacesInfo = function() {
	var tableEl = this._getEl("placesList");
	var missing = 0;

	Framework.Common.nodesForEach(tableEl.children, function(item) {
		item.classList.remove("missing");

		var id = item.getAttribute("data-id");
		if (!id) return;

		var place = this._getPanoramaByID(parseInt(id, 10));

		if (!place.description.trim().length || typeof place.kappa !== "number" || !place.lon || !place.lat) {
			item.classList.add("missing");
			missing++;
		}
	}, this);

	this._placesMissingParams = missing > 0;
	this._getEl("missingInfo").classList[this._placesMissingParams ? "add" : "remove"]("show");
};

/**
 * Preset change - waiting for stiching.
 */
Stitcherweb.TourDetailPage._presetChange = function() {
	this._checkForIds();
};

// ------------------------ public ----------------------------------------

/**
 * Add place snippet.
 */
Stitcherweb.TourDetailPage.addPlace = function() {
	if (this._currentSnippet && this._currentSnippet.isLocked()) {
		return;
	}

	// we need tour id
	var id = parseInt(this._getConfig().id, 10);

	var addNewPlaceEl = Stitcherweb.UploadSnippet.init({
		id: id,
		presets: this._getConfig().presets
	}, this);

	this._setOutput(addNewPlaceEl, Stitcherweb.UploadSnippet);

	this._activeMarker();
};

/**
 * Edit place snippet
 * @param  {Number} id
 */
Stitcherweb.TourDetailPage.editPlace = function(id) {
	if (
		(this._currentSnippet && this._currentSnippet.isLocked()) || 
		id == this._panoramaID
	) {
		return;
	}

	var editPlaceEl = Stitcherweb.EditPlaceSnippet.init({
		place: this._getPanoramaByID(id),
		presets: this._getConfig().presets,
		debug: this._getConfig().debug
	}, this);

	this._setOutput(editPlaceEl, Stitcherweb.EditPlaceSnippet);

	this._activeMarker(id);
};

/**
 * Event - Delete place from the template
 * @param  {Number} id
 */
Stitcherweb.TourDetailPage.deletePlace = function(id) {
	var notify = Framework.Notify.get(this._getEl("placesAlert")).reset();

	if (!this._isTourEditable()) {
		notify.error(_("tour_detail.delete_disabled"));
		return;
	}

	Framework.Common.confirm(_("tour_detail.delete_confirm")).then(function() {
		Stitcherweb.PanoramaResource.remove(id).then(function() {
			// remove from list
			// change view if the deleted pano was the shown one
			this._deletePlaceFromTable(id);

			// remove place from the list
			this._panoramaList.every(function(item, ind) {
				if (item.id == id) {
					this._panoramaList.splice(ind, 1);
					return false;
				}
				else return true;
			}, this);

			// update markers
			this._map.updateMarkers(this._panoramaList);

			// update places info
			this._updatePlacesInfo();

			notify.ok(_("tour_detail.delete")).hide();

			if (this._panoramaID == id) {
				// switch view to add new place
				this._panoramaID = null;
				this.addPlace();
			}
		}.bind(this), function() {
			notify.error(_("tour_detail.delete_error"));
		});
	}.bind(this));
};

/**
 * Event - update tour
 */
Stitcherweb.TourDetailPage.saveTour = function() {
	var pg = this._getConfig();
	var tourName = this._getEl("tourName").value;
	var diffObj = {};
	var changed = false;
	var notify = Framework.Notify.get(this._getEl("alert")).reset();

	// only name
	if (tourName.length && tourName != pg.tour.name) {
		diffObj["name"] = tourName;
		changed = true;
	}

	// there is some change?
	if (changed) {
		Stitcherweb.TourResource.updateTour(pg.id, diffObj).then(function(data) {
			// update place
			Framework.Common.extend(pg.tour, diffObj);

			notify.ok(_("tour_detail.tour_update")).hide();
		}, function(data) {
			notify.error(Stitcherweb.Helper.handleErrorMsg(data));
		});
	}
	else {
		notify.error(_("tour_detail.no_change"));
	}
};

/**
 * Event - send tour to editor
 */
Stitcherweb.TourDetailPage.sendTour = function() {
	var notify = Framework.Notify.get(this._getEl("alert")).reset();

	// some place missing params
	if (this._placesMissingParams) {
		notify.error(_("tour_detail.save_missing_params"));
		return;
	}

	Stitcherweb.TourResource.sendTour(this._getConfig().id).then(function(data) {
		this._getEl("tourState").innerHTML = _("tour_states.s");
		this._addTourStateClass("state-s");

		// set state to S
		this._getTourData().state = "S";

		// update buttons
		this._tourStateAction();

		notify.ok(_("tour_detail.tour_send")).hide();
	}.bind(this), function(data) {
		notify.error(Stitcherweb.Helper.handleErrorMsg(data));
	});
};

/**
 * Event - approve/reject tour
 * @param  {String} action
 */
Stitcherweb.TourDetailPage.tourAction = function(action) {
	var text = this._getEl("editorsComment").value;
	var notify = Framework.Notify.get(this._getEl("alertEditor")).reset();

	var postData = {}

	// some place missing params
	if (this._placesMissingParams) {
		notify.error(_("tour_detail.save_missing_params"));
		return;
	}
	
	if (text) {
		postData.comment = text;
	}

	Stitcherweb.TourResource[action == "approve" ? "approveTour" : "rejectTour"](this._getConfig().id, postData).then(function(data) {
		var infoEl = this._getEl("tourState");

		if (action == "approve") {
			infoEl.innerHTML = _("tour_states.a");
			this._getTourData().state = "A";
			this._addTourStateClass("state-a");
		}
		else {
			infoEl.innerHTML = _("tour_states.r");
			this._getTourData().state = "R";
			this._addTourStateClass("state-r");
		}

		// update buttons
		this._tourStateAction();

		notify.ok(_("tour_detail.tour_editor_update")).hide();
	}.bind(this), function(data) {
		notify.error(Stitcherweb.Helper.handleErrorMsg(data));
	});
};

/**
 * Get map object
 * @return {Object}
 */
Stitcherweb.TourDetailPage.getMap = function() {
	return this._map;
};

/**
 * On key down - search input under the map.
 * @param  {KeyDownEvent} e
 */
Stitcherweb.TourDetailPage.onKeydown = function(e) {
	var keyCode = e.which || e.keyCode;

	if (keyCode == 13) {
		this.search();
	}
};

/**
 * Search
 */
Stitcherweb.TourDetailPage.search = function() {
	var val = this._getEl("search").value;
	val = val ? val.trim() : null;

	// make search - done is called after succesfull search
	this._search.makeSearch(val).done(function() {
		this._scrollToMainPart();
	}.bind(this));
};
