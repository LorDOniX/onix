/*
 * Trida pro rozmazavani fotek
 * Oznaceni kruhovych a primkovych casti obrazu, nasledne odeslani souradnic na backend
 * Na backendu se provadi samotne rozmazani fotek
 * SVG platno musi byt presne pres obrazek
 *
 * @param {array} opt - nastaveni
 * @param {string} opt.svgId - element svg platna
 * @param {string} opt.NS - NS svg 
 * @param {string} opt.inputCircleEl - el inputu s prumerem kruhu 
 * @param {string} opt.inputLineEl - el inputu s tloustkou cary 
 * @param {string} opt.radioCircleEl - el radio s vybranym kruhem 
 * @param {string} opt.radioLineEl -  el radio s vybranou carou
 * @param {string} opt.circleFill - barva vyplne kruhu
 * @param {string} opt.circleFillOpacity - pruhlednost kruhu
 * @param {string} opt.lineFill - barva cary
 * @param {string} opt.lineFillOpacity - pruhlednost cary
 */
Stitcherweb.BlurPicture = function(opt) {
	this.opt = {};
	this.opt.svgEl = null;													// el elementu svg platna
	this.opt.NS = 'http://www.w3.org/2000/svg'; 							// NS svg
	this.opt.inputCircleEl = null; 											// el inputu s prumerem kruhu
	this.opt.inputLineEl = null;											// el inputu s tloustkou cary
	this.opt.radioCircleEl = null;											// el radio s vybranym kruhem
	this.opt.radioLineEl = null; 											// el radio s vybranou carou
	this.opt.circleFill = '#0000FF'; 										// barva vyplne kruhu
	this.opt.circleFillOpacity = '0.5';										// pruhlednost kruhu
	this.opt.lineFill = '#00FF00'; 											// barva cary
	this.opt.lineFillOpacity = '0.5';										// pruhlednost cary
	this.opt.circleMax = 50;												// maximální polomer kruhu
	this.opt.lineMax = 100; 												// maximálni sirka cary

	for (var i in opt) {
		this.opt[i] = opt[i];
	}

	// elementy ze stranky s kterymi pracujeme
	this.svg = this.opt.svgEl;
	this.inputCircle = this.opt.inputCircleEl;
	this.inputLine = this.opt.inputLineEl;
	this.radioCircle = this.opt.radioCircleEl;
	this.radioLine = this.opt.radioLineEl;
	this.sourceImg = this.opt.sourceImgEl;

	if (!this.inputCircle || !this.inputLine || !this.radioCircle || !this.radioLine || !this.sourceImg) {
		console.log('Chyba - element ze stranky nenalezen');
	}

	// pomocne promenne
	this.svgObjects = []; 						// pole zadanych svg objektu [{x, y, r, elm}, {x1, x2, y1, y2, width, elm}]
	this.eventMouseUp = null; 					// ID eventu mouseUp pro konec kresleni
	this.eventMouseMoveLine = null;				// ID eventu posouvani nahledu cary
	this.eventMouseMoveCircle = null; 			// ID eventu posouvani nahledu kruhu
	this.eventMouseUpPreviewLine = null;		// ID eventu ukonceni nahledu cary
	this.eventMouseUpPreviewCircle = null; 		// ID eventu ukonceni nahledu kruhu
	this.elmPreviewLine = null; 				// element nahledu cary
	this.elmPreviewCircle = null; 				// element nahledu kruhu

	// eventy
	JAK.Events.addListener(this.svg, 'mousedown', this, this._svgMouseDown.bind(this)); 	// zacatek kresleni
};

/* Udalost klik nad platnem
 * - kruh - vola pridani kruhu
 * - cara - nedela nic
 */
Stitcherweb.BlurPicture.prototype._svgClick = function(e, elm) {

	// vybrana cara, koncime
	var type = this._selectedType();
	if (!type || type == 'line') {
		return;
	}

	this._svgPosition();

	// poloha mysi
	var mousePosition = this._mousePosition(e);
	// polomer kruhu
	var r = parseInt(this.inputCircle.value);
}

/* Udalost zacatku stisknuti tlacitka nad platnem
 * dle typu objektu vola zacatek jejich vykreslovani
 */
Stitcherweb.BlurPicture.prototype._svgMouseDown = function(e, elm) {
	
	JAK.Events.cancelDef(e);
	JAK.Events.stopEvent(e);

	// zustala-li navesena udalost, vycistime ji
	if (this.eventMouseUp) {
		JAK.Events.removeListener(this.eventMouseUp);
		this.eventMouseUp = null;
	}

	// zustaly-li docasne nahledove objekty, odstranime je
	if (this.elmPreviewLine) {
		this.svg.removeChild(this.elmPreviewLine);
		this.elmPreviewLine = null;
	}

	if (this.elmPreviewCircle) {
		this.svg.removeChild(this.elmPreviewCircle);
		this.elmPreviewCircle = null;
	}

	// defaultni nacteni pozice a rozmeru svg platna
	this._svgPosition();

	// podle typu vykreslime objekt
	var type = this._selectedType();
	if (type == 'circle') {
		// kruh
		this._startDrawCircle(e);
	} else if (type == 'line') {
		// cara
		this._startDrawLine(e);
	} else {
		//chyba
		console.log('Chyba - nevybran typ');
	}
}

/* Obsluhuje zacatek kresleni cary
 * nacte pocatecni souradnice cary
 * navesi udalosti na konec kresleni a na kresleni nahledoveho objektu
 */
Stitcherweb.BlurPicture.prototype._startDrawLine = function(e) {

	// poloha mysi
	var mousePosition = this._mousePosition(e);

	// zustala-li navesena udalost, vycistime ji
	if (this.eventMouseMoveLine) {
		JAK.Events.removeListener(this.eventMouseMoveLine);
		this.eventMouseMoveLine = null;
	}

	// tloustka cary
	var width = parseInt(this.inputLine.value);

	if (width && width <= this.opt.lineMax) {
		// udalost ukonceni kresleni cary
		this.eventMouseUp = JAK.Events.addListener(this.svg, 'mouseup', this, this._finishDrawLine.bind(this, mousePosition.x, mousePosition.y));

		// udalost prekreslovani nahledu cary
		this.eventMouseMoveLine = JAK.Events.addListener(this.svg, 'mousemove', this, this._svgMouseMoveLine.bind(this, mousePosition.x, mousePosition.y));
	} else {
		console.log('Chyba - tloustka cary');
	}
}

/* Obsluhuje zacatek kresleni kruhu
 * vykresli nahledovy objekt kruhu
 * navesi udalosti na konec kresleni a na kresleni nahledoveho objektu
 */
Stitcherweb.BlurPicture.prototype._startDrawCircle = function(e) {

	// poloha mysi
	var mousePosition = this._mousePosition(e);

	if (this.eventMouseMoveCircle) {
		JAK.Events.removeListener(this.eventMouseMoveCircle);
		this.eventMouseMoveCircle = null;
	}

	var r = parseInt(this.inputCircle.value);

	// pridame kruh
	if (r && r <= this.opt.circleMax) {
		// preview element kruhu
		this.elmPreviewCircle = this._drawCircle(mousePosition.x, mousePosition.y, r);

		// udalost dokonceni kresleni kruhu
		this.eventMouseUp = JAK.Events.addListener(this.svg, 'mouseup', this, this._finishDrawCircle.bind(this));

		// udalost prekresleni pozice preview kruhu
		this.eventMouseMoveCircle = JAK.Events.addListener(this.svg, 'mousemove', this, this._svgMouseMoveCircle.bind(this));

		// udalost ukonceni nahledu kruhu
		this.eventMouseUpPreviewCircle = JAK.Events.addListener(document.body, 'mouseup', this, this._mouseUpPreviewCircle.bind(this));
	} else {
		console.log('Chyba - polomer kruhu');
	}
}

/* Udalost konce stisknuti tlacitka pri kresleni kruhu
 * vola pridani kruhu do objektu a nasledne vykresleni do svg platna
 */
Stitcherweb.BlurPicture.prototype._finishDrawCircle = function(e, elm) {

	JAK.Events.cancelDef(e);

	if (this.eventMouseUp) {
		JAK.Events.removeListener(this.eventMouseUp);
		this.eventMouseUp = null;
	}

	// vybrana cara, koncime
	var type = this._selectedType();
	if (!type || type == 'line') {
		return;
	}

	// poloha mysi
	var mousePosition = this._mousePosition(e);
	// polomer kruhu
	var r = parseInt(this.inputCircle.value);

	// pridame kruh
	if (r) {
		this._addCircle(mousePosition.x, mousePosition.y, r);
	} else {
		console.log('Chyba - polomer kuruhu');
	}
}

/* Udalost konce stisknuti tlacitka pri kresleni cary
 * vola pridani cary do objektu a nasledne vykresleni do svg platna
 */
Stitcherweb.BlurPicture.prototype._finishDrawLine = function(x, y, e, elm) {

	JAK.Events.cancelDef(e);

	if (this.eventMouseUp) {
		JAK.Events.removeListener(this.eventMouseUp);
		this.eventMouseUp = null;
	}

	if (this.eventMouseMoveLine) {
		JAK.Events.removeListener(this.eventMouseMoveLine);
		this.eventMouseMoveLine = null;
	}

	// vybran kruh, koncime - nemelo by nastat - ozkousime
	var type = this._selectedType();
	if (!type || type == 'circle') {
		console.log('Chyba - pri mouseup vybran kruh');
		return;
	}

	// poloha mysi
	var mousePosition = this._mousePosition(e);
	// tloustka cary
	var width = parseInt(this.inputLine.value);

	if (width) {
		this._addLine(x, mousePosition.x, y, mousePosition.y, width);
	} else {
		console.log('Chyba - tloustka cary');
	}
}

/* Udalost konce stisknuti tlacitka v dokumentu pri kresleni kruhu
 * odstranuje docasny nahledovy objekt kruhu
 */
Stitcherweb.BlurPicture.prototype._mouseUpPreviewCircle = function(e, elm) {

	if (this.elmPreviewCircle) {
		this.svg.removeChild(this.elmPreviewCircle);
		this.elmPreviewCircle = null;
	}

	if (this.eventMouseUpPreviewCircle) {
		JAK.Events.removeListener(this.eventMouseUpPreviewCircle);
		this.eventMouseUpPreviewCircle = null;
	}

	if (this.eventMouseMoveCircle) {
		JAK.Events.removeListener(this.eventMouseMoveCircle);
		this.eventMouseMoveCircle = null;
	}
}

/* Udalost konce stisknuti tlacitka v dokumentu pri kresleni cary
 * odstranuje docasny nahledovy objekt cary
 */
Stitcherweb.BlurPicture.prototype._mouseUpPreviewLine = function(e, elm) {

	if (this.elmPreviewLine) {
		this.svg.removeChild(this.elmPreviewLine);
		this.elmPreviewLine = null;
	}

	if (this.eventMouseUpPreviewLine) {
		JAK.Events.removeListener(this.eventMouseUpPreviewLine);
		this.eventMouseUpPreviewLine = null;
	}

	if (this.eventMouseMoveLine) {
		JAK.Events.removeListener(this.eventMouseMoveLine);
		this.eventMouseMoveLine = null;
	}
}

/* Udalost pohybu mysi nad svg platnem pri kresleni cary
 * pokud neni nahledovy element, vytvari jej
 * prekresluje nahledovy element cary, 
 * pocatecni souradnice zustavaji, koncove se meni na pozici mysi
 */
Stitcherweb.BlurPicture.prototype._svgMouseMoveLine = function(x, y, e, elm) {

	JAK.Events.cancelDef(e);
	JAK.Events.stopEvent(e);

	var mousePosition = this._mousePosition(e);

	if (!this.elmPreviewLine) {

		// tloustka cary
		var width = parseInt(this.inputLine.value);

		this.elmPreviewLine = this._drawLine(x, mousePosition.x, y, mousePosition.y, width);
		this.svg.appendChild(this.elmPreviewLine);

		this.eventMouseUpPreviewLine = JAK.Events.addListener(document.body, 'mouseup', this, this._mouseUpPreviewLine.bind(this));
	} else {

		this.elmPreviewLine.setAttribute('x2', mousePosition.x);
		this.elmPreviewLine.setAttribute('y2', mousePosition.y);
	}
}

/* Udalost pohybu mysi nad svg platnem pri kresleni kruhu
 * meni souradnice stredu kruhu na souradnice mysi
 */
Stitcherweb.BlurPicture.prototype._svgMouseMoveCircle = function(e, elm) {

	JAK.Events.cancelDef(e);
	JAK.Events.stopEvent(e);

	var mousePosition = this._mousePosition(e);

	if (this.elmPreviewCircle) {
		this.elmPreviewCircle.setAttribute('cx', mousePosition.x);
		this.elmPreviewCircle.setAttribute('cy', mousePosition.y);
	}
}

/* Zjisteni pozice mysi nad svg platnem */
Stitcherweb.BlurPicture.prototype._mousePosition = function(e) {
	
	var pageX = e.pageX;
	var pageY = e.pageY;

	//Zarovy konstanty
	pageX = pageX - 2;
	pageY = pageY - 2;

	var svgX = pageX - this.zeroPosition.x;
	var svgY = pageY - this.zeroPosition.y;

	if (svgX < 0) {
		svgX = 0;
	}
	if (svgY < 0) {
		svgY = 0;
	}

	return {x: svgX, y:svgY};
}

/* Zjisteni pozice svg platna v dokumentu
 * pro nasledne pocitani pozice mysi
 * zjisteni rozmeru svg platna 
 */
Stitcherweb.BlurPicture.prototype._svgPosition = function() {

	if (!this.zeroPosition) {
		var position = JAK.DOM.getBoxPosition(this.svg);

		this.zeroPosition = {
			x: parseInt(position.left),
			y: parseInt(position.top)
		};

		this.svgSize = {
			width: parseInt(this.svg.getAttribute('width')),
			height: parseInt(this.svg.getAttribute('height'))
		}
	}
}

/* Pridani kruhu do pole objektu
 * vola vykresleni kruhu 
 */
Stitcherweb.BlurPicture.prototype._addCircle = function(x, y, r) {

	var circle = {
		type: 'circle',
		x: x,
		y: y,
		r: r,
		elm: null
	};

	circle.elm = this._drawCircle(x, y, r);

	this.svgObjects.push(circle);
}

/* Pridani cary do pole objektu
 * vola vykresleni cary 
 */
Stitcherweb.BlurPicture.prototype._addLine = function(x1, x2, y1, y2, width) {

	// klikl jsme na miste, bod nepridavam
	if (x1 == x2 && y1 == y2) {
		return;
	}

	var line = {
		type: 'line',
		x1: x1,
		y1: y1,
		x2: x2,
		y2: y2,
		width: width,
		elm: null
	};

	line.elm = this._drawLine(x1, x2, y1, y2, width);

	this.svgObjects.push(line);
}

/* Vykresleni kruhu do svg 
 * vraci ukazatel na element 
 */
Stitcherweb.BlurPicture.prototype._drawCircle = function(x, y, r) {

	var elm = document.createElementNS(this.opt.NS, 'circle');

	elm.setAttribute('fill', this.opt.circleFill);
  	elm.setAttribute('fill-opacity', this.opt.circleFillOpacity);

	elm.setAttribute('cx', parseInt(x));
  	elm.setAttribute('cy', parseInt(y));
  	elm.setAttribute('r', parseInt(r));

  	this.svg.appendChild(elm);

	return elm;
}

/* Vykresleni cary do svg
 * vraci ukazatel na element 
 */
Stitcherweb.BlurPicture.prototype._drawLine = function(x, x2, y, y2, width) {

	var elm = document.createElementNS(this.opt.NS, 'line');

	elm.setAttribute('x1', x);
	elm.setAttribute('x2', x2);
	elm.setAttribute('y1', y);
	elm.setAttribute('y2', y2);
	elm.setAttribute('stroke-width', width);

	elm.setAttribute('stroke', this.opt.lineFill);
	elm.setAttribute('stroke-opacity', this.opt.lineFillOpacity);

  	this.svg.appendChild(elm);

  	return elm;
}

/* 
 * Odmazani posledniho objektu 
 */
Stitcherweb.BlurPicture.prototype.stepBack = function() {
	// nejsou zadne objekty
	if (this.svgObjects.length == 0) {
		return;
	}

	var obj = this.svgObjects.pop();
	this.svg.removeChild(obj.elm);
}

/* Odmazani vsech objektu 
 */
Stitcherweb.BlurPicture.prototype.clearAll = function() {
	var length = this.svgObjects.length

	// nejsou zadne objekty
	if (length == 0) {
		return;
	}

	for (var i = 0; i < length; i++) {
		var obj = this.svgObjects.pop();
		this.svg.removeChild(obj.elm);
	}
}

/* 
 * odeslani dat 
 */
Stitcherweb.BlurPicture.prototype.getJSONData = function(e, elm) {
	var blurImageActions = {};	 									// data pro AJAX handler

	var list 	= this._cloneArrayOfObjects(this.svgObjects); 		// jednoduchá kopie pole JSON objektů s elementy
 	var parent 	= JAK.DOM.findParent(this.svg, 'div.entry'); 		// element obalující informace
	var img 	= this.sourceImg;									// element reprezentující fotografii

	// zobrazená velikost obrázku
	var width 	= img.width; 										
	var height  = img.height;

	if (list.length) {
		// základní informace + incializace informací o provedených akcí	
		blurImageActions['image'] 		= { 'width': width, 'height': height };
		blurImageActions['actions'] 	= [];

		// odstranění zbytečné reference na element
		for (var i = 0; i < list.length; i++) {
			delete list[i].elm;
			blurImageActions['actions'].push(list[i]);	
		}

		return blurImageActions;
	}

	return null;
}

/* Vytvoření kopie pole objektů
 * problém při JSON.parse(JSON.stringify(obj)) v chrome
 */
Stitcherweb.BlurPicture.prototype._cloneArrayOfObjects = function (array) {
	var copyArray = [];
	for (var i = 0; i < array.length; i++) {
		var obj = array[i];
		if (null == obj || "object" != typeof obj) continue;
	    var copy = obj.constructor();
	    for (var attr in obj) {
	        if (obj.hasOwnProperty(attr)) copy[attr] = obj[attr];
	    }
	    copyArray.push(copy);
    }
    return copyArray;
}

/* Zjistujeni typu vybraneho tvaru
 * kruh - vraci 'circle'
 * cara - vraci 'line' 
 */
Stitcherweb.BlurPicture.prototype._selectedType = function() {

	if (this.radioCircle.checked) {
		return 'circle';
	} else if (this.radioLine.checked) {
		return 'line';
	} else {
		console.log('Chyba - nevybran tvar');
		return;
	}
};
