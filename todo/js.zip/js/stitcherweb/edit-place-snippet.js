Stitcherweb.EditPlaceSnippet = Stitcherweb.Snippet.create();

// ------------------------ private ---------------------------------------

/**
 * Create snippet from the template
 * @param  {Object} config
 * @return {NodeElement} root el
 */
Stitcherweb.EditPlaceSnippet._create = function(config) {
	this._savedPlace = {};

	var place = config.place || {};

	// copy place to the new object
	Framework.Common.extend(this._savedPlace, place);

	this._const = {
		KAPPA_HALF_WIDTH: 2,
		SLIDER_CIRCLE_VAL: 50,
		SLIDER_LINE_VAL: 20,
		HIDE_CLASS: "hide"
	};

	this._setName("edit-place");
	this._skipLock = false;

	var imgSrc = "";

	if (this._isPlaceOK()) {
		imgSrc = (config.debug ? Stitcherweb.DEBUG_IMG_SERVER : "") + place.previewUrl;
	}

	var root = Framework.DOM.create({
		el: "div",
		"class": "edit-place",
		innerHTML: Framework.Template.compile("editPlaceTmpl", {
			DESCRIPTION: place.description,
			ID: place.id,
			LON: place.lon || "",
			LAT: place.lat || "",
			KAPPA: place.kappa || 0,
			IMG_SRC: imgSrc + this._getTS(),
			STATE: Stitcherweb.Helper.getPanoramaState(place.state)
		})
	});

	return root;
};

/**
 * Event - circle change
 * @param  {Object} data Event data
 */
Stitcherweb.EditPlaceSnippet._sliderCircleEvent = function(data) {
	var svgCircle = this._getEl("svgCircle");
	var radioCircle = this._getEl("radioCircle");

	if (data.value != svgCircle.getAttribute("r")) {
		svgCircle.setAttribute("r", data.value);
	}

	if (!radioCircle.checked) {
		radioCircle.checked = true;
	}
};

/**
 * Event - line change
 * @param  {Object} data Event data
 */
Stitcherweb.EditPlaceSnippet._sliderLineEvent = function(data) {
	var svgLine = this._getEl("svgLine");
	var radioLine = this._getEl("radioLine");

	if (data.value != svgLine.getAttribute("stroke-width")) {
		svgLine.setAttribute("stroke-width", data.value);
	}
	
	if (!radioLine.checked) {
		radioLine.checked = true;
	}
};

/**
 * Create sliders for circle/line
 */
Stitcherweb.EditPlaceSnippet._createSliders = function() {
	var s1 = new Stitcherweb.Slider("sliderCircle",{
		width: 250,
		height: 10,
		max: 50,
		actualValue: 40,
		riderH: 18,
		input: this._getEl("inputCircle"),
		onEvent: this._sliderCircleEvent.bind(this)
	});

	var s2 = new Stitcherweb.Slider("sliderLine",{
		width: 250,
		height: 10,
		max: 100,
		riderH: 18,
		input: this._getEl("inputLine"),
		onEvent: this._sliderLineEvent.bind(this)
	});

	s1.setValue(this._const.SLIDER_CIRCLE_VAL);
	s2.setValue(this._const.SLIDER_LINE_VAL);
};

/**
 * Create blur picture
 */
Stitcherweb.EditPlaceSnippet._createBlurPicture = function() {
	this._blurPicture = new Stitcherweb.BlurPicture({
		svgEl: this._getEl("svg"),
		inputCircleEl: this._getEl("inputCircle"), // hodnoty kruhu a lajny
		inputLineEl: this._getEl("inputLine"),
		radioCircleEl: this._getEl("radioCircle"), // co je vybrano - kruh, lajna
		radioLineEl: this._getEl("radioLine"),
		sourceImgEl: this._getEl("imgBlur") // zdrojovy obrazek
	});
};

/**
 * Setup - create all elements, set kappa and map state
 */
Stitcherweb.EditPlaceSnippet._setup = function() {
	this._map = this._getParent().getMap();

	this._getParent().trigger("layout-change", {
		map: true
	});

	this._createSliders();
	this._createBlurPicture();
	this._setKappa(this._getConfig().place.kappa);
	this._setMapState();
	this._presetID = this._savedPlace.presetID;
	
	this._presetSelect = new Framework.Select(this._getEl("presetSelect"), {
		addCaption: true
	});
	this._presetSelect.on("change", this._presetChange, this);
	this._presetSelect.setAddCaption();
	this._setPresets();


	this.updateStatus();
};

/**
 * On activate - bind map events
 */
Stitcherweb.EditPlaceSnippet._activate = function() {
	this._map.on("marker-add", this._markerAdd, this);
	this._map.on("marker-dragged", this._markerDragged, this);

	this._getParent().on("place-update", this._placeUpdate, this);

	this.on("tour-state-update", this._tourStateUpdate, this);
	this.on("show-save-info", this._saveInfo, this);
};

/**
 * On deactivate - unbind map events; default map state
 */
Stitcherweb.EditPlaceSnippet._deactivate = function() {
	this._map.off("marker-add", this._markerAdd);
	this._map.off("marker-dragged", this._markerDragged);

	var parent = this._getParent();
	parent.off("place-update", this._placeUpdate);

	this.off("tour-state-update", this._tourStateUpdate);
	this.off("show-save-info", this._saveInfo);

	this._map.setState(this._map.MAP_STATES.NORMAL);

	parent.trigger("layout-change", {
		map: true
	});
};

/**
 * Update position - place and input boxes.
 * @param  {Event} pos 
 */
Stitcherweb.EditPlaceSnippet._updatePosition = function(pos) {
	// update place
	var place = this._getConfig().place;
	
	place.lon = pos.lon;
	place.lat = pos.lat;

	// update inputs
	this._getEl("placeLon").value = pos.lon;
	this._getEl("placeLat").value = pos.lat;
};

/**
 * Place update from the parent.
 * @param {Object} place
 */
Stitcherweb.EditPlaceSnippet._placeUpdate = function(place) {
	// update img srcs
	var ts = this._getTS();
	var imgSrc = place.previewUrl + ts;

	this._getEl("imgPreview").src = imgSrc;
	this._getEl("imgBlur").src = imgSrc;

	this.updateStatus();
};

/**
 * Event - marker add; makes own marker-update event
 * @param  {Object} event
 */
Stitcherweb.EditPlaceSnippet._markerAdd = function(event) {
	this._updatePosition(event);

	this._getParent().trigger("marker-update", this._getConfig().place);
};

/**
 * Event - marker dragged
 * @param  {Object} event
 */
Stitcherweb.EditPlaceSnippet._markerDragged = function(event) {
	this._updatePosition(event);
};

/**
 * Get coordinates from inputs.
 * @return {Object}
 */
Stitcherweb.EditPlaceSnippet._getCoords = function() {
	var placeLon = this._getEl("placeLon").value;
	var placeLat = this._getEl("placeLat").value;

	placeLon = placeLon.length ? parseFloat(placeLon) : 0;
	placeLat = placeLat.length ? parseFloat(placeLat) : 0;

	return {
		// true - coords are ok / false
		status: placeLon > 0 && placeLat > 0,

		lon: placeLon,
		lat: placeLat,

		// create smap coords
		getMapCoords: function() {
			if (this.status) {
				return SMap.Coords.fromWGS84(this.lon, this.lat);
			}
			else {
				return null;
			}
		}
	};
};

/**
 * Set kappa based on place value - during setup() phase
 * @param {Number} value
 */
Stitcherweb.EditPlaceSnippet._setKappa = function(value) {
	value = value || 0;

	var imgEl = this._getEl("imgPreview");
	var blurEl = this._getEl("imgBlur");

	// phantom img -> test for image load
	var img = new Image();
	img.addEventListener("error", function() {
		var noImageSrc = "/static/img/no-image.png";
		
		imgEl.src = noImageSrc;
		blurEl.src = noImageSrc;
	});
	img.src = imgEl.src;
	img.onload = function() {
		var kappaEl = this._getEl("kappa");

		var pos = Math.round(imgEl.offsetWidth * value / 360);

		kappaEl.style.left = (pos - this._const.KAPPA_HALF_WIDTH) + "px";
	}.bind(this);
};

/**
 * Set map states based on current place coordinates
 */
Stitcherweb.EditPlaceSnippet._setMapState = function() {
	var coords = this._getCoords();
	var states = this._map.MAP_STATES;

	this._map.setState(coords.status ? states.NORMAL : states.ADD);
};

/**
 * Is place OK ? Annonyzaied or stitched
 * @return {Boolean}
 */
Stitcherweb.EditPlaceSnippet._isPlaceOK = function() {
	var place = this._getConfig().place;

	return place.state == "S" || place.state == "A";
};

/**
 * Event - tour-state-update
 * @param  {Boolean} disabled
 */
Stitcherweb.EditPlaceSnippet._tourStateUpdate = function(disabled) {
	// admin - do not disable anything
	if (Stitcherweb.getConfig("USER_IS_ADMIN")) {
		return;
	}
	
	// buttons
	var all = [
		this._getEl("deletePlaceBtn"),
		this._getEl("savePlaceBtn"),
		this._getEl("stepBackBtn"),
		this._getEl("clearAllBtn"),
		this._getEl("blurImgBtn"),
		this._getEl("photoNorhtBtn")
	];

	// disabled buttons
	all.forEach(function(el) {
		el.disabled = disabled;
	});
};

/**
 * Get snippet change
 * @return {Object}
 */
Stitcherweb.EditPlaceSnippet._getChange = function() {
	var placeDescription = this._getEl("placeDescription").value;
	var placeKappa = this._getEl("placeKappa").value;
	var coords = this._getCoords();

	placeKappa = placeKappa ? parseInt(placeKappa, 10) : null;

	var changed = false;
	var diffObj = {};
	var place = this._savedPlace; // saved place for compare

	if (placeDescription != place.description) {
		changed = true;
		diffObj["description"] = placeDescription;
	}

	if (coords.lon && coords.lon != place.lon) {
		changed = true;
		diffObj["lon"] = coords.lon;
	}

	if (coords.lat && coords.lat != place.lat) {
		changed = true;
		diffObj["lat"] = coords.lat;
	}

	if (placeKappa != place.kappa && placeKappa > 0) {
		changed = true;
		diffObj["kappa"] = placeKappa;
	}

	if (this._presetID != place.presetID) {
		changed = true;
		diffObj["presetID"] = this._presetID;
	}

	return {
		changed: changed, // is changed?
		obj: diffObj // obj with change
	};
};

/**
 * Is snippet locked for change?
 */
Stitcherweb.EditPlaceSnippet._isLocked = function() {
	var chObj = this._getChange();

	if (!this._skipLock && chObj.changed) {
		this._saveInfo();
		this._getParent()._scrollToMainPart();
		this._skipLock = true;

		return true;
	}
	else {
		this._skipLock = false;

		return false;
	}
};

/**
 * Information about unsaved changes.
 */
Stitcherweb.EditPlaceSnippet._saveInfo = function() {
	Framework.Notify.get(this._getEl("placeAlert")).reset().warn(_("edit_place.unsaved_info"));
};

/**
 * Change select value.
 */
Stitcherweb.EditPlaceSnippet._presetChange = function(value) {
	this._presetID = parseInt(value, 10);
};

/**
 * Request for preset change with confirm window.
 * @param {Nubmer} changePresetID
 * @param {Object} notify
 */
Stitcherweb.EditPlaceSnippet._changePreset = function(changePresetID, notify) {
	if (typeof changePresetID === "undefined") return;

	Framework.Common.confirm(_("edit_place.preset_change_confirm")).then(function() {
		var id = this._getConfig().place.id;
		var postData = [{
			name: "id",
			value: changePresetID
		}];

		Stitcherweb.PanoramaResource.setPreset(id, postData).then(function() {
			this._savedPlace.presetID = changePresetID;
			this._savedPlace.state = "P"; // stitching
			
			var place = this._getConfig().place;
			place.presetID = changePresetID;
			place.state = "P";

			this.updateStatus();
			this._getParent().trigger("preset-change");

			notify.ok(_("edit_place.preset_change_done")).hide();
		}.bind(this), function(data) {
			notify.error(Stitcherweb.Helper.handleErrorMsg(data));
		});
	}.bind(this));
};


/**
 * Set data for presets.
 */
Stitcherweb.EditPlaceSnippet._setPresets = function() {
	var dropdownEl = this._getEl("presetSelect");
	var presets = this._getConfig().presets;
	var count = this._getConfig().place.photoCount;
	var find = null;

	Object.keys(presets).every(function(presetsCount) {
		if (presetsCount == count) {
			find = presets[presetsCount];
			return false;
		}
		else return true;
	});

	if (find) {
		var outputEl = this._getEl("panoramaPresets");
		var selInd = 0;

		dropdownEl.classList.remove(this._const.HIDE_CLASS);
		
		outputEl.innerHTML = "";

		find.forEach(function(presetItem, ind) {
			var DOMobj = {
				el: "li",
				child: [{
					el: "a",
					href: "javascript:void(0)",
					innerHTML: presetItem.name,
					attrs: {
						"data-value": presetItem.id
					}
				}]
			};

			if (this._presetID == presetItem.id) {
				selInd = ind;
			}

			outputEl.appendChild(Framework.DOM.create(DOMobj));
		}, this);

		this._presetSelect.rebindChoices();
		this._presetSelect.selectOption(selInd);
	}
	else {
		dropdownEl.classList.add(this._const.HIDE_CLASS);
	}
};

/**
 * Get TS
 * @return {String}
 */
Stitcherweb.EditPlaceSnippet._getTS = function() {
	return ("?ts=" + new Date().getTime().toString(16));
};

// ------------------------ public ----------------------------------------

/**
 * Show anonymization tab
 */
Stitcherweb.EditPlaceSnippet.showBlur = function() {
	if (!this._isPlaceOK()) {
		var notify = Framework.Notify.get(this._getEl("previewAlert"));

		notify.error(_("edit_place.place_loading"));

		setTimeout(function() {
			notify.reset();
			notify.info(_("edit_place.info"));
		}, 1500);
		return;
	}

	this._getEl("preview").style.display = "none";
	this._getEl("blur").style.display = "block";
	this._getEl("previewLi").classList.remove("active");
	this._getEl("blurLi").classList.add("active");

	this._getParent().trigger("layout-change", {
		map: false,
		scroll: true
	});
};

/**
 * Show preview tab
 */
Stitcherweb.EditPlaceSnippet.showPreview = function() {
	this._getEl("preview").style.display = "block";
	this._getEl("blur").style.display = "none";
	this._getEl("previewLi").classList.add("active");
	this._getEl("blurLi").classList.remove("active");

	this._getParent().trigger("layout-change", {
		map: true,
		scroll: true
	});
};

/**
 * Event - blur image
 */
Stitcherweb.EditPlaceSnippet.blurImg = function() {
	var data = this._blurPicture.getJSONData();
	var notify = Framework.Notify.get(this._getEl("alert")).reset();

	if (data) {
		Framework.Loader.start();

		Stitcherweb.PanoramaResource.blurImage(this._getConfig().place.id, data).then(function() {
			Framework.Loader.end();

			this._blurPicture.clearAll();

			// update img srcs
			var ts = this._getTS();
			this._getEl("imgPreview").src += ts;
			this._getEl("imgBlur").src += ts;

			notify.ok(_("edit_place.blur_done")).hide();
		}.bind(this), function(data) {
			Framework.Loader.end();

			notify.error(Stitcherweb.Helper.handleErrorMsg(data));
		});
	}
	else {
		notify.error(_("edit_place.blur_no_data"));
	}
};

/**
 * Event - delete place; propage to this parent, new event place-remove
 */
Stitcherweb.EditPlaceSnippet.deletePlace = function() {
	this._getParent().trigger("place-remove", this._getConfig().place.id);
};

/**
 * Event - save place (update)
 */
Stitcherweb.EditPlaceSnippet.savePlace = function() {
	var notify = Framework.Notify.get(this._getEl("placeAlert")).reset();
	var chObj = this._getChange();

	if (chObj.changed) {
		var place = this._savedPlace; // saved place for compare
		var placeDescription = this._getEl("placeDescription").value;
		var presetObj = null;

		if ("presetID" in chObj.obj) {
			presetObj = {
				id: chObj.obj["presetID"]
			};
			delete chObj.obj["presetID"];
		}

		// is there anything left?
		if (Object.keys(chObj.obj).length) {
			Stitcherweb.PanoramaResource.updatePanorama(place.id, chObj.obj).then(function(data) {
				// update place
				Framework.Common.extend(place, chObj.obj);

				var el = Framework.DOM.get("tr[data-id='" + place.id + "'] .scene-name");
				if (el) {
					el.innerHTML = placeDescription;
				}

				notify.ok(_("edit_place.update")).hide();

				// update places info - name is filled
				this._getParent().trigger("place-save", {
					id: this._getConfig().place.id,
					place: place
				});

				// change preset ID?
				if (presetObj) {
					this._changePreset(presetObj.id, notify);
				}
			}.bind(this), function(data) {
				notify.error(Stitcherweb.Helper.handleErrorMsg(data));
			});
		}
		else if (presetObj) {
			// change preset ID?
			this._changePreset(presetObj.id, notify);
		}
	}
	else {
		notify.error(_("edit_place.no_update"));
	}
};

/**
 * Event - show position on the map.
 */
Stitcherweb.EditPlaceSnippet.showOnMap = function() {
	var coords = this._getCoords();

	if (coords.status) {
		this._map.setCenter(coords.getMapCoords());
	}
};

/**
 * Event - click on the image - select new kappa
 * @param {Event} event
 * @param {NodeElement} el    Image el
 */
Stitcherweb.EditPlaceSnippet.setKappa = function(event, el) {
	var kappaEl = this._getEl("kappa");

	var clickPos = event.layerX || event.offsetX;
	var kappa = Math.round(clickPos / el.offsetWidth * 360);

	this._getEl("placeKappa").value = kappa;
	
	// 2 is half diff o kappa img
	kappaEl.style.left = (clickPos - this._const.KAPPA_HALF_WIDTH) + "px";
};

/**
 * Event - blur image - take one step back
 */
Stitcherweb.EditPlaceSnippet.stepBack = function() {
	this._blurPicture.stepBack();
};

/**
 * Event - blur image - clear all geometries
 */
Stitcherweb.EditPlaceSnippet.clearAll = function() {
	this._blurPicture.clearAll();
};

/**
 * Update place status.
 */
Stitcherweb.EditPlaceSnippet.updateStatus = function() {
	// update img src
	var place = this._getConfig().place;

	var loadingEl = this._getEl("loading");
	var previewHolderEl = this._getEl("previewHolder");
	var stateEl = this._getEl("state");

	stateEl.innerHTML = Stitcherweb.Helper.getPanoramaState(place.state);

	if (this._isPlaceOK()) {
		loadingEl.classList.add("hide");
		previewHolderEl.classList.remove("hide");
		stateEl.classList.remove("error");
	}
	else if (place.state == "E") {
		stateEl.classList.add("error");
		loadingEl.classList.add("hide");
	}
	else {
		loadingEl.classList.remove("hide");
		previewHolderEl.classList.add("hide");
		stateEl.classList.remove("error");
	}
};

/**
 * Is snippet changed?
 * @return {Boolean}
 */
Stitcherweb.EditPlaceSnippet.isChanged = function() {
	var change = this._getChange();

	return change.changed;
};

/**
 * Set photo azimuth to north
 */
Stitcherweb.EditPlaceSnippet.setPhotoToNorth = function() {
	if (this._isPlaceOK()) {
		var NORTH_DEG = 180;

		this._setKappa(NORTH_DEG);
		this._getEl("placeKappa").value = NORTH_DEG;
	}
};
