Stitcherweb.Map = function(el, parent) {
	// extend our class
	Framework.Common.extend(this, Framework.Event);

	this._map = null;
	this._parent = parent;

	// marker types
	this.MARKER_TYPE = {
		RED: "a_normal",
		GREEN: "a_normal_green"
	};

	// map states
	this.MAP_STATES = {
		NORMAL: 0,
		ADD: 1
	};

	this._CONST = {
		MAP_HEIGHT: "700px",
		PADDING: 25,
		SIZE: [27, 51],
		ANCHOR: {left:14, top:49},
		CENTER: SMap.Coords.fromWGS84(14.41790, 50.12655)
	};

	this._markers = [];
	this._state = this.MAP_STATES.NORMAL;

	if (el) {
		var center = this._CONST.CENTER;

		// def. map height
		el.style.height = this._CONST.MAP_HEIGHT;

		this._map = new SMap(el, center, 13, {minZoom:2, maxZoom:18});
		this._map.addDefaultControls();
		this._map_layers = {};
		this._map_layers[SMap.DEF_BASE] = this._map.addDefaultLayer(SMap.DEF_BASE);
		this._map_layers[SMap.DEF_OPHOTO] = this._map.addDefaultLayer(SMap.DEF_OPHOTO);

		// default
		this._map_layers[SMap.DEF_BASE].enable();

		this._layer = new SMap.Layer.Marker();
		this._map.addLayer(this._layer).enable();

		var signals = this._map.getSignals();

		// signals
		signals.addListener(this, "marker-click", "_markerClick");
		signals.addListener(this, "map-click", "_mapClick");
		signals.addListener(this, "marker-drag-stop", "_markerDragStop");

		// ophoto switcher
		this._addOphotoSwitcher(el);
	}
};

// ------------------------ private ---------------------------------------
	
/**
 * Set map cursor.
 * @param {Boolean} [add] Move x add new baloon cursor
 */
Stitcherweb.Map.prototype._setCursor = function(add) {
	if (add) {
		this._map.setCursor("url('/static/img/balloon/green.png'), pointer", 14, 49);
	}
	else {
		this._map.setCursor("move");
	}
};

/**
 * Get map parent.
 * @return {NodeElement}
 */
Stitcherweb.Map.prototype._getParent = function() {
	return this._parent;
};

/**
 * Event - marker click, makes own marker-click event
 * @param  {Event} e
 */
Stitcherweb.Map.prototype._markerClick = function(e) {
	var marker = e.target;

	this.trigger("marker-click", marker.getId());
};

/**
 * Event - marker drag, makes own marker-dragged event
 * @param  {Event} e
 */
Stitcherweb.Map.prototype._markerDragStop = function(e) {
	var coords = e.target.getCoords();

	this.trigger("marker-dragged", {
		lon: coords.x,
		lat: coords.y
	});
};

/**
 * Center all markers.
 * @param  {Array} allCoords
 */
Stitcherweb.Map.prototype._centerAllMarkers = function(allCoords) {
	if (allCoords.length) {
		var data = this._map.computeCenterZoom(allCoords, this._CONST.PADDING);
		
		this._map.setCenterZoom(data[0], data[1]);
	}
};

/**
 * Event - map click, makes own marker-add event
 * @param  {Event} e
 */
Stitcherweb.Map.prototype._mapClick = function(e) {
	if (this._state == this.MAP_STATES.ADD) {
		var dome = e.data.event;
		var coords = SMap.Coords.fromEvent(dome, this._map);

		// default state
		this.setState(this.MAP_STATES.NORMAL);

		this.trigger("marker-add", {
			lon: coords.x,
			lat: coords.y
		});
	}
};

/**
 * Add ophoto switcher
 *
 * @param {NodeElement} el
 */
Stitcherweb.Map.prototype._addOphotoSwitcher = function(el) {
	var hudEl = el.querySelector(".hud .noprint");

	hudEl.appendChild(Framework.DOM.create({
		el: "div",
		"class": ["btn", "btn-sm", "btn-default", "btn-ophoto"],
		innerHTML: _("map.ophoto"),
		events: [{
			event: "click",
			fn: Framework.Common.bindWithoutScope(function(ev, scope) {
				if (this.classList.contains("btn-default")) {
					this.classList.remove("btn-default");
					this.classList.add("btn-success");

					scope._map.setZoomRange(2, 20);
					scope._map_layers[SMap.DEF_BASE].disable();
					scope._map_layers[SMap.DEF_OPHOTO].enable();
				}
				else {
					this.classList.remove("btn-success");
					this.classList.add("btn-default");

					scope._map.setZoomRange(2, 18);
					scope._map_layers[SMap.DEF_BASE].enable();
					scope._map_layers[SMap.DEF_OPHOTO].disable();
				}
			}, this)
		}]
	}));
};

// ------------------------ public ----------------------------------------

/**
 * Set new map state.
 * @param {Enum} state
 */
Stitcherweb.Map.prototype.setState = function(state) {
	this._state = state;

	if (state == this.MAP_STATES.NORMAL) {
		this._setCursor();
	}
	else {
		this._setCursor(true);
	}
};

/**
 * Get map element
 * @return {Object}
 */
Stitcherweb.Map.prototype.getMap = function() {
	return this._map;
};

/**
 * Start map sync - not using.
 */
Stitcherweb.Map.prototype.startSync = function() {
	var sync = new SMap.Control.Sync({ bottomSpace: this._CONST.PADDING });
	this._map.addControl(sync);
};

/**
 * Add new marker.
 * @param {Object} place
 * @param {Object} [config] { pos, type }
 */
Stitcherweb.Map.prototype.addMarker = function(place, config) {
	place = place || {};
	config = config || {};

	if (place.lat && place.lon) {
		var type = config.type || this.MARKER_TYPE.RED;
		var pos = config.pos || 0;
		var coords = SMap.Coords.fromWGS84(place.lon, place.lat);

		var marker = new SMap.Marker(coords, place.id, {
			size: this._CONST.SIZE,
			anchor: this._CONST.ANCHOR,
			url: Framework.DOM.create({
				el: "div",
				"class": ["animated-balloon", type],
				attrs: {
					style: "width: " + this._CONST.SIZE[0] + "px; height: " + this._CONST.SIZE[1] + "px",
					"data-pos": pos,
					"data-id": place.id
				},
				child: [
					{
						el: "span",
						"class": "number",
						innerHTML: pos 
					}
				]
			})
		});

		marker.decorate(SMap.Marker.Feature.Draggable);

		//JAK.Events.addListener(marker.getContainer()[SMap.LAYER_MARKER], "mouseover", this, "_mouseOver");
		//JAK.Events.addListener(marker.getContainer()[SMap.LAYER_MARKER], "mouseout", this, "_mouseOut");

		this._markers.push(marker);
		this._layer.addMarker(marker);

		return marker;
	}
	else {
		return null;
	}
};

/**
 * Create markers from places array.
 * @param  {Array} panoPlaces
 */
Stitcherweb.Map.prototype.createMarkers = function(panoPlaces) {
	panoPlaces = panoPlaces || [];

	var allCoords = [];

	panoPlaces.forEach(function(pano, ind) {
		var marker = this.addMarker(pano, { pos: ind + 1 });

		if (marker) {
			allCoords.push(marker.getCoords());
		}
	}, this);

	this._centerAllMarkers(allCoords);
};

/**
 * Update - add/remove markers on the map.
 * @param  {Array} panoPlaces
 * @param  {Boolean} [dontCenter] Center all markers?
 */
Stitcherweb.Map.prototype.updateMarkers = function(panoPlaces, dontCenter) {
	panoPlaces = panoPlaces || [];
	var allCoords = [];

	var markers = {};
	this._layer.getMarkers().forEach(function(marker) {
		markers[marker.getId()] = marker;
	});

	panoPlaces.forEach(function(pano, ind) {
		if (pano.lat && pano.lon) {
			var marker = markers[pano.id];

			if (marker) {
				var number = marker.getContainer()[SMap.LAYER_MARKER].querySelector(".number");
				number.innerHTML = ind + 1;
				delete markers[pano.id];

				allCoords.push(marker.getCoords());
			}
			else {
				marker = this.addMarker(pano, {
					pos: ind + 1
				});

				allCoords.push(marker.getCoords());
			}
		}
	}, this);

	// markers contains marks for delete
	Object.keys(markers).forEach(function(marker) {
		this._layer.removeMarker(markers[marker]);
	}, this);

	if (!dontCenter) {
		this._centerAllMarkers(allCoords);
	}
};

/**
 * Update draggable markers.
 * @param  {Number} [id]
 */
Stitcherweb.Map.prototype.updateDraggable = function(id) {
	this._layer.getMarkers().forEach(function(marker) {
		marker.setDrag(marker.getId() == id ? true : false);
	});
};

/**
 * Set map center.
 * @param {Object} coords
 */
Stitcherweb.Map.prototype.setCenter = function(coords) {
	if (coords) {
		this._map.setCenter(coords);
	}
};

/**
 * Get map center.
 * @return {Object}
 */
Stitcherweb.Map.prototype.getCenter = function() {
	return this._map.getCenter();
};

/**
 * Remove all marker - it is not using
 */
Stitcherweb.Map.prototype.removeAllMarkers = function() {
	this._layer.removeAll();
};

/**
 * Compute zoom from poi.
 * @param  {Object} poi
 * @return {Number}
 */
Stitcherweb.Map.prototype.computeZoom = function(poi) {
	var source = poi.source;
	
	var zooms = {
		"ward": 13,
		"quar": 13,
		"muni": 12,
		"dist": 9,
		"area": 8,
		"regi": 6,
		"coun": 3,
		"pubt": 17
	};
	
	var zoom = zooms[source] || 17;
	
	// restaurace Andel napr.
	if (source == "area" && (poi.typeId == "9" || poi.entityCategory == 9)) {
		zoom = 16;
	}
	
	/* zoomovani pro osm poiserver */
	var arr = ["lvl1", "lvl10", "lvl11", "lvl2", "lvl3", "lvl4", "lvl5", "lvl6", "lvl7", "lvl8", "lvl9", "osmp", "osms", "osma", "osmd"];
	if(arr.indexOf(source) != -1) {
		if(source == "muni") {
			zoom = 14;
		} else {
			zoom = 16;
		}
	}

	return zoom;
};
