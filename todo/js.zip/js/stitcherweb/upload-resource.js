Stitcherweb.UploadResource = (function() {
	// ------------------------ public ---------------------------------------
	
	var UploadResource = function() {};
	
	/**
	 * Upload images.
	 * @param  {Object|Array} postData
	 * @return {Promise}
	 */
	UploadResource.prototype.upload = function(postData) {
		postData = postData || {};
		
		return Framework.HTTP.createRequest({
			method: "post",
			url: Stitcherweb.URLS.UPLOAD,
			postType: Framework.HTTP.POST_TYPES.FORM_DATA,
			postData: postData,
			headers: [
				Stitcherweb.Helper.getCSRFheader()
			]
		});
	};

	return new UploadResource();
})();
