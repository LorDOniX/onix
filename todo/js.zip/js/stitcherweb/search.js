/**
 * Search
 * @param  {Object} map
 * @param  {NodeElement} searchResultsEl
 */
Stitcherweb.Search = function(map, searchResultsEl) {
	this._map = map;
	this._promise = null;
	this._srEl = searchResultsEl;
};

// ------------------------ private ----------------------------------------

/**
 * Create search results.
 * @param  {Object} geo SMAP Geocoder
 */
Stitcherweb.Search.prototype._createSearchResults = function(geo) {
	var r = geo.getResults();
	var map = this._map;

	if (r && r.length) {
		r = r[0].results;

		r.forEach(function(item) {
			var line = Framework.DOM.create({
				el: "li",
				"class": "list-group-item",
				child: [{
					el: "a",
					attrs: {
						"data-x": item.coords.x,
						"data-y": item.coords.y,
						"data-zoom": map.computeZoom(item)
					},
					href: "javascript:void(0)",
					innerHTML: item.label,
					events: [{
						event: "click",
						fn: Framework.Common.bindWithoutScope(function(ev, scope) {
							var x = this.getAttribute("data-x");
							var y = this.getAttribute("data-y");
							var zoom = parseInt(this.getAttribute("data-zoom"), 10);

							map.setCenter(SMap.Coords.fromWGS84(x, y), zoom);

							// resolve search promise
							scope._promise.resolve();
						}, this)
					}]
				}]
			});

			this._srEl.appendChild(line);
		}, this);

		if (!r.length) {
			this._srEl.appendChild(Framework.DOM.create({
				el: "li",
				"class": "list-group-item",
				innerHTML: _("tour_detail.search_not_found")
			}));
		}
	}
};

// ------------------------ public ----------------------------------------

/**
 * Map search - geocode
 *
 * @param {String} val
 * @return {Promise}
 */
Stitcherweb.Search.prototype.makeSearch = function(val) {
	// clear all previous items
	Framework.MyQuery.get(this._srEl).empty();

	this._promise = Framework.Promise.defer();

	if (val) {
		new SMap.Geocoder(val, this._createSearchResults.bind(this));
	}
	else {
		this._promise.reject();
	}

	return this._promise;
};
