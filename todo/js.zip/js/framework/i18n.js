Framework.i18n = (function() {
	var i18n = function() {};

	/**
	 * All langs data.
	 *
	 * @private
	 * @type {Object}
	 * @memberof i18n
	 */
	i18n.prototype._langs = {};

	/**
	 * Current language
	 *
	 * @private
	 * @type {String}
	 * @memberof i18n
	 */
	i18n.prototype._currentLang = "";

	/**
	 * Add a new language
	 *
	 * @public
	 * @param {String} lang Language key
	 * @param {Object} data
	 * @memberof i18n
	 */
	i18n.prototype.addLanguage = function(lang, data) {
		this._langs[lang] = data;
	};

	/**
	 * Set new language by his key.
	 *
	 * @public
	 * @param {String} lang Language key
	 * @memberof i18n
	 */
	i18n.prototype.setLanguage = function(lang) {
		this._currentLang = lang;
	};

	/**
	 * Get text function. Translate for the current language and the key.
	 *
	 * @public
	 * @param  {String} key
	 * @param  {Object} replace Replace all {} in the string
	 * @return {String}    
	 * @memberof i18n
	 */
	i18n.prototype._ = function(key, replace) {
		key = key || "";
		var lObj = this._langs[this._currentLang];
		var translate = "";

		if (lObj) {
			var parts = key.split(".");
			var len = parts.length;

			parts.every(function(item, ind) {
				if (item in lObj) {
					lObj = lObj[item];

					if (ind == len - 1) {
						translate = lObj;
						return false;
					}
				}
				else return false;

				// go on
				return true;
			});
		}

		return this._transReplace(translate, replace);
	};

	/**
	 * Replace translated text by object.
	 *
	 * @public
	 * @param  {String} translate
	 * @param  {Object} replace Replace all {} in the string
	 * @return {String}    
	 * @memberof i18n
	 */
	i18n.prototype._transReplace = function(translate, replace) {
		translate = translate || "";
		replace = replace || {};

		var replaceParts = translate.match(/{[^}]+,.*}|{[^}]*}/g);

		if (replaceParts) {
			var finalReplace = {};

			replaceParts.forEach(function(part) {
				var key = part;

				if (key.length > 2) {
					key = key.substr(1, key.length - 2);
				}

				// multi
				var parts = key.split(",");
				var name = parts[0].trim();
				var multiPartsObj = {};

				if (parts.length == 2) {
					var multiParts = parts[1].match(/[a-zA-Z0-9_]+{[^}]*}/g);

					if (multiParts) {
						multiParts.forEach(function(mpart) {
							var mpartSplits = mpart.split("{");
							var mpartValue = mpartSplits[1];
							mpartValue = mpartValue.substr(0, mpartValue.length - 1);

							multiPartsObj[mpartSplits[0].trim()] = mpartValue;
						});
					}
				}

				var replaceValue = name in replace ? replace[name] : "";

				if (typeof replaceValue === "number" && Object.keys(multiPartsObj).length) {
					var multiKey;

					switch (replaceValue) {
						case 1:
							multiKey = "one";
							break;

						case 2:
						case 3:
						case 4:
							multiKey = "few";
							break;

						default:
							multiKey = "other";
					}

					replaceValue = multiKey in multiPartsObj ? multiPartsObj[multiKey] : "";
				}

				finalReplace[part] = replaceValue;
			});

			Object.keys(finalReplace).forEach(function(key) {
				translate = translate.replace(new RegExp(key, "g"), finalReplace[key]);
			});
		}

		return translate;
	};

	/**
	 * Load language from the file.
	 *
	 * @public
	 * @param  {String} lang Language key
	 * @param  {String} url  Path to the file
	 * @return {Framework.Promise}
	 * @memberof i18n
	 */
	i18n.prototype.loadLanguage = function(lang, url) {
		var promise = Framework.Promise.defer();

		Framework.HTTP.createRequest({
			url: url
		}).then(function(data) {
			this.addLanguage(lang, data.data);
			promise.resolve();
		}.bind(this), function(data) {
			promise.resolve();
		});

		return promise;
	};

	var i18nInstance = new i18n();

	// bind _ for language
	window._ = i18nInstance._.bind(i18nInstance);

	return i18nInstance;
})();
