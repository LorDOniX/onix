Framework.Loader = (function() {
	var Loader = function() {};

	/**
	 * Create Loader.
	 *
	 * @private
	 * @memberof Loader
	 */
	Loader.prototype._create = function() {
		this._el = Framework.DOM.create({
			el: "div",
			"class": "loader"
		});

		// insert into the body on first position
		document.body.insertBefore(this._el, document.body.firstChild);
	};
	
	/**
	 * Loader init.
	 *
	 * @public
	 * @memberof Loader
	 */
	Loader.prototype.init = function() {
		this._create();
	};

	/**
	 * Start loader.
	 *
	 * @public
	 * @memberof Loader
	 */
	Loader.prototype.start = function() {
		this._el.classList.add("start");
	};

	/**
	 * End loader.
	 *
	 * @public
	 * @memberof Loader
	 */
	Loader.prototype.end = function() {
		this._el.classList.remove("start");
		this._el.classList.add("end");

		setTimeout(function() {
			this._el.classList.remove("end");
			this._el.classList.add("hide");

			setTimeout(function() {
				this._el.classList.remove("hide");
			}.bind(this), 350);
		}.bind(this), 150);
	};

	var loaderInstance = new Loader();

	// bind dom ready
	Framework.on("dom-ready", loaderInstance.init, loaderInstance);

	return loaderInstance;
})();
